<?php 
session_start();

if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name'])  && isset($_SESSION['role']) ) {
  
    $user_name = $_SESSION['user_name'];
    $role = $_SESSION['role'];

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $current_password = $_POST["current_password"];
        $new_password = $_POST["new_password"];
        $confirm_password = $_POST["confirm_password"];

        // Check if the new password and confirmation match
        if ($new_password !== $confirm_password) {
            header("Location: change_password.php?error=Passwords do not match. Please try again.");
            exit();
        }

        // Establish a database connection
        $conn = new mysqli("localhost", "root", "", "admin");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Assuming your table is named "users" and the current password is stored in a column named "password"
        $username =  $user_name; // No need to wrap in double quotes

        $stmt = $conn->prepare("SELECT password FROM admin_table WHERE user_name = ?");
        $stmt->bind_param("s", $username);

        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($stored_password);

        if ($stmt->num_rows === 1 && $stmt->fetch()) {
            // Password is fetched from the database
            if (password_verify($current_password, $stored_password)) {
                // Current password is valid

                // Hash the new password
                $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);

                // Update the password in the database
                $update_stmt = $conn->prepare("UPDATE admin_table SET password = ? WHERE user_name = ?");
                $update_stmt->bind_param("ss", $new_password_hash, $username);

                if ($update_stmt->execute()) {
                   
                    if ($role === 'admin') {
                        header("Location: ../admin-dashboard/profile.php?success=1");
            
                        // header("Location: ../admin-dashboard/dashboard.php");
                    } elseif ($role === 'user') {
                        header("Location: ../user-dashboard/profile.php?success=1");
                        // header("Location: ../user-dashboard/userindex.php");
                    } else {
                        // Handle other roles or scenarios
                        header("Location: default_page.php");
                    }
                    exit();
                } else {
                    echo "Error updating password: " . $conn->error;
                }

                $update_stmt->close();
            } else {
                header("Location: change_password.php?error=Invalid current password. Please try again.");
                exit();
            }
        } else {
            header("Location: change_password.php?error=User not found.");
            exit();
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "Invalid request.";
    }
} else {
    echo "Session variables not set. Please log in.";
}
?>
