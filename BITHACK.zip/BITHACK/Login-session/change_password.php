<?php 
session_start();

if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name'])  && isset($_SESSION['role']) ) {
  ?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $_SESSION['event_org']; ?> <?php echo $_SESSION['event_type']; ?></title>
    <!-- <title>BIT HACK 23</title> -->
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>



<form action="update_password.php" method="post">
<h2>Change Password</h2>
    <?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
       
    <label for="current_password">Current Password:</label><br>
    <input type="password" id="current_password" name="current_password" required><br>

    <label for="new_password">New Password:</label><br>
    <input type="password" id="new_password" name="new_password" required><br>

    <label for="confirm_password">Confirm New Password:</label><br>
    <input type="password" id="confirm_password" name="confirm_password" required><br><br>

    <input type="submit" value="Update Password">
</form>

</body>
</html>
<?php 
}else{
     header("Location: ../login-session/index.php");
     exit();
}
 ?>