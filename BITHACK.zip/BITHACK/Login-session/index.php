<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
	<h1>BIT HACK'23</h1>
     <form action="admin_login.php" method="post"><marquee behavior="alternate" scrollamount="10" direction="left" style="background-color:rgb(170, 191, 195);font-family:bold" >BIT HACK'23 Welcomes You!!</marquee>
     	<h2>LOGIN</h2>
		
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
     	<label>User Name</label>
     	<input type="text" name="uname" placeholder="User Name"><br>

     	<label>Password</label>
     	<input type="password" name="password" placeholder="Password"><br>

     	<button type="submit" >Login</button>
		 
          <a href="update_display.php" class="ca">Change Display Details</a>
		  
		  <a href="#" class="ca" onclick="showAlert()">Forget Password</a>
     </form>
	 <script>
        function showAlert() {
            alert("Contact Your Admin!!");
        }
    </script>
</body>
</html>