<?php
session_start();
include "db_conn.php"; // Assuming this connects to your database

function validate($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (isset($_POST['uname']) && isset($_POST['password'])) {

    $uname = validate($_POST['uname']);
    $pass = validate($_POST['password']);

    if (empty($uname) || empty($pass)) {
        header("Location: index.php?error=Both username and password are required");
        exit();
    } else {

        // Check if session is active and not expired
        if (isset($_SESSION['start_time'])) {
            $session_duration = time() - $_SESSION['start_time'];
            $session_timeout = 30 * 60; // 30 minutes in seconds

            if ($session_duration > $session_timeout) {
                session_unset(); // Unset all session variables
                session_destroy(); // Destroy the session
                header("Location: index.php?error=Session expired. Please log in again.");
                exit();
            }
        }

        // Use prepared statement for the first table
        $stmt1 = $conn->prepare("SELECT * FROM admin_table WHERE user_name = ?");
        $stmt1->bind_param("s", $uname);
        $stmt1->execute();
        $result1 = $stmt1->get_result();

        // if ($result1->num_rows === 1) $username && password_verify($pass, $hashed_password)
        if ($result1->num_rows === 1) {
            $row1 = $result1->fetch_assoc();
            $hashed_password = $row1['password'];

            if (password_verify($pass, $hashed_password)) {

            // Use the id from table1 to fetch data from table2
            // $id = $row1['id']; // Assuming 'id' is the actual field name in table1
            $id = '1';
            // Use prepared statement for the second table with the id from table1
            $stmt2 = $conn->prepare("SELECT * FROM admin_display WHERE id = ?");
            $stmt2->bind_param("i", $id); // Assuming 'id' is an integer
            $stmt2->execute();
            $result2 = $stmt2->get_result();

            if ($result2->num_rows === 1) {
                $row2 = $result2->fetch_assoc();

                // Store user information from the first table in the session
                $_SESSION['name'] = $row1['name'];
                $_SESSION['staff_id'] = $row1['staff_id'];
                $_SESSION['designation'] = $row1['designation'];
                $_SESSION['domain'] = $row1['domain'];
                $_SESSION['user_name'] = $row1['user_name'];
                $_SESSION['role'] = $row1['role'];
                $_SESSION['db_name'] = $row1['db_name'];

                // Store user information from the second table in the session
                $_SESSION['event_org'] = $row2['event_org'];
                $_SESSION['event_type'] = $row2['event_type'];
                $_SESSION['organizer'] = $row2['organizer']; // Adjust with actual field name

                // Determine the destination page based on the username
                if ($row1['role'] === 'admin') {
                    header("Location: ../admin-dashboard/dashboard.php");
                } elseif ($row1['role'] === 'user') {
                    header("Location: ../user-dashboard/userindex.php");
                } else {
                    // Handle other roles or scenarios
                    header("Location: create_admin.php");
                }
                exit();
            } else {
                header("Location: index.php?error=Data not found in admin_display");
                exit();
            }
        } else {
            // Password is incorrect
            header("Location: index.php?error=Incorrect username or password");
            exit();
        }
            
        } else {
            header("Location: index.php?error=Incorrect username or password");
            exit();
        }
    }
} else {
    header("Location: index.php");
    exit();
}
?>
