<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Update Event</title>
</head>
<body>

    <form action="update_process.php" method="post">
        <h2>Change Display Details</h2>
		
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
        Event Organization: <input type="text" name="event_organization" placeholder="Bit" required><br>
        Event Type: <input type="text" name="event_type" placeholder="Hack'23" required><br>
        Organizer: <input type="text" name="organization" placeholder="Special Laboratories" required><br>
        Seceret Key: <input type="password" name="usersecretkey" placeholder="Seceret Key" required><br>
        <input type="submit" value="Submit">
        <a href="index.php" class="ca">Back to Login</a>
        <a href="super_index.php" class="ca">Super Admin</a>
    </form>

</body>
</html>
