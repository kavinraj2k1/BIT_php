<?php 
session_start();

if (isset($_SESSION['ID']) && isset($_SESSION['User_name']) && isset($_SESSION['First_name'])&& isset($_SESSION['Last_name'])&& isset($_SESSION['Email'])&& isset($_SESSION['Date_of_Birth'])&& isset($_SESSION['Phone'])&& isset($_SESSION['Country'])&& isset($_SESSION['City'])&& isset($_SESSION['Postal_Code'])&& isset($_SESSION['Degree'])&& isset($_SESSION['Course'])&& isset($_SESSION['D_Year_of_Completion'])&& isset($_SESSION['Sslc'])&& isset($_SESSION['S_Year_of_Completion'])&& isset($_SESSION['Hsc'])&& isset($_SESSION['H_Year_of_Completion'])&& isset($_SESSION['Area_Of_Interest'])&& isset($_SESSION['Hobbies'])&& isset($_SESSION['Project'])&& isset($_SESSION['Linkedin_Link'])&& isset($_SESSION['Github_Link'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
     <h1>Hello, <?php echo $_SESSION['Email']; ?></h1>
     <a href="logout.php">Logout</a>
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>