<?php
include "db_conn.php";


$secretkey='bitsathysecretkey@12345';
$event_organization = $_POST['event_organization'];
$event_type = $_POST['event_type'];
$organization = $_POST['organization'];

$usersecretkey=$_POST['usersecretkey'];
if($secretkey === $usersecretkey)
{
    $sql = "UPDATE admin_display SET event_org='$event_organization', event_type='$event_type', organizer='$organization' WHERE id=1";

    echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
    header("Location: index.php");
} else 
{
    header("Location: update_display.php?error=Error updating record:");
    exit();
    // echo "Error updating record : " . $conn->error;
}
}
else
{
    header("Location: update_display.php?error=You have entered wrong Seceret Key....");
    exit();
    // echo "You have entered wrong Seceret Key....";
}



$conn->close();
?>
