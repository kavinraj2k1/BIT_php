<?php
session_start();
include "db_conn1.php"; // Assuming this connects to your database
function validate($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (isset($_POST['uname']) && isset($_POST['password'])) {

    $uname = validate($_POST['uname']);
    $pass = validate($_POST['password']);

    if (empty($uname) || empty($pass)) {
        header("Location: super_index.php?error=Both username and password are required");
        exit();
    } else {

        // Check if session is active and not expired
        if (isset($_SESSION['start_time'])) {
            $session_duration = time() - $_SESSION['start_time'];
            $session_timeout = 30 * 60; // 30 minutes in seconds

            if ($session_duration > $session_timeout) {
                session_unset(); // Unset all session variables
                session_destroy(); // Destroy the session
                header("Location: super_index.php?error=Session expired. Please log in again.");
                exit();
            }
        }

        // Use prepared statement for the first table
        $stmt1 = $conn->prepare("SELECT * FROM admin_data WHERE user_name = ?");
        $stmt1->bind_param("s", $uname);
        $stmt1->execute();
        $result1 = $stmt1->get_result();

        if ($result1->num_rows === 1) {
            $row1 = $result1->fetch_assoc();
            $hashed_password = $row1['password'];

            if (password_verify($pass, $hashed_password)) {

                // Store user information in the session
                $_SESSION['name'] = $row1['name'];
                $_SESSION['user_name'] = $row1['user_name'];
                $_SESSION['role'] = $row1['role'];
                echo("Hello");
                // // Determine the destination page based on the username
                // if ($row1['role'] === 'superadmin') {
                //     header("Location: ../super-admin/create_admin.php");
                // } else {
                //     header("Location: ../hisuper-admin/create_admin.php"); // Make sure this path is correct
                // }
                // header("Location: ../super-admin/create_admin.php");
                // exit();
                header("Location:../super-admin/super_user.php");
            } else {
                // Password is incorrect
                header("Location: super_index.php?error=Incorrect username or password");
                exit();
            }
        } else {
            // Username not found
            header("Location: super_index.php?error=Incorrect username or password");
            exit();
        }
    }
} else {
    header("Location: super_index.php");
    exit();
}
?>
