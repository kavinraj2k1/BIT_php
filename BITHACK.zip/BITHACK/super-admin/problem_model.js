document.addEventListener('DOMContentLoaded', () => {
    const adminDbModal = document.getElementById('admin-db-modal');
    const userDbModal = document.getElementById('user-db-modal');
    const adminDetailsModal = document.getElementById('admin-details-modal');

    const openAdminDbModalBtn = document.getElementById('open-admin-db-modal-btn');
    const openUserDbModalBtn = document.getElementById('open-user-db-modal-btn');
    const openAdminDetailsModalBtn = document.getElementById('open-admin-details-modal-btn');

    const closeAdminDbModalBtn = document.querySelector('#admin-db-modal .close-modal');
    const closeUserDbModalBtn = document.querySelector('#user-db-modal .close-modal');
    const closeAdminDetailsModalBtn = document.querySelector('#admin-details-modal .close-modal');

    openAdminDbModalBtn.addEventListener('click', () => {
        adminDbModal.style.display = 'block';
    });

    openUserDbModalBtn.addEventListener('click', () => {
        userDbModal.style.display = 'block';
    });

    openAdminDetailsModalBtn.addEventListener('click', () => {
        adminDetailsModal.style.display = 'block';
    });

    closeAdminDbModalBtn.addEventListener('click', () => {
        adminDbModal.style.display = 'none';
    });

    closeUserDbModalBtn.addEventListener('click', () => {
        userDbModal.style.display = 'none';
    });

    closeAdminDetailsModalBtn.addEventListener('click', () => {
        adminDetailsModal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target == adminDbModal) {
            adminDbModal.style.display = 'none';
        }

        if (event.target == userDbModal) {
            userDbModal.style.display = 'none';
        }

        if (event.target == adminDetailsModal) {
            adminDetailsModal.style.display = 'none';
        }
    });
});
