<?php
$servername = "localhost"; // e.g., localhost
$username = "root";
$password = "";

if(isset($_POST['dbname'])) {
    $dbname = $_POST['dbname'];

    // Create connection
    $conn = new mysqli($servername, $username, $password);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS $dbname";
    if ($conn->query($sql) === TRUE) {
        header("Location: super_user.php?success=1");
        // exit();
        // echo "Database $dbname created successfully<br>";
    } else {
        echo "Error creating database: " . $conn->error;
    }

    // Connect to the newly created database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create tables
    $sql_table1 = "CREATE TABLE IF NOT EXISTS admin_display (
        id INT AUTO_INCREMENT PRIMARY KEY,
        event_org VARCHAR(255) NOT NULL,
        event_type VARCHAR(255) NOT NULL,
        organizer VARCHAR(255) NOT NULL
    )";

    $sql_table2 = "CREATE TABLE IF NOT EXISTS admin_notify (
        id INT AUTO_INCREMENT PRIMARY KEY,
        notification TEXT NOT NULL,
        date_time DATETIME NOT NULL
    )";

    $sql_table3 = "CREATE TABLE IF NOT EXISTS admin_table (
        id INT AUTO_INCREMENT UNIQUE,
        name VARCHAR(255) NOT NULL,
        staff_id VARCHAR(20) NOT NULL,
        designation VARCHAR(255) NOT NULL,
        domain VARCHAR(255) NOT NULL,
        user_name VARCHAR(255) PRIMARY KEY,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(255) NOT NULL,
        db_name VARCHAR(255) NOT NULL
    )";

    $sql_table4 = "CREATE TABLE IF NOT EXISTS events (
        event_name VARCHAR(255) NOT NULL,
        event_type VARCHAR(255) NOT NULL,
        date DATE NOT NULL,
        status VARCHAR(255) NOT NULL
    )";

    $sql_table5 = "CREATE TABLE problem_statement (
        problem_code VARCHAR(50) PRIMARY KEY,
        problem_statement TEXT NOT NULL,
        domain VARCHAR(255) NOT NULL
    )";

    if ($conn->query($sql_table1) === TRUE) {
        echo "Table 'table1' created successfully<br>";
    } else {
        echo "Error creating table 'table1': " . $conn->error;
    }

    if ($conn->query($sql_table2) === TRUE) {
        echo "Table 'table2' created successfully<br>";
    } else {
        echo "Error creating table 'table2': " . $conn->error;
    }

    if ($conn->query($sql_table3) === TRUE) {
        echo "Table 'table3' created successfully<br>";
    } else {
        echo "Error creating table 'table3': " . $conn->error;
    }

    if ($conn->query($sql_table4) === TRUE) {
        echo "Table 'table4' created successfully<br>";
    } else {
        echo "Error creating table 'table4': " . $conn->error;
    }

    if ($conn->query($sql_table5) === TRUE) {
        echo "Table 'table5' created successfully<br>";
    } else {
        echo "Error creating table 'table5': " . $conn->error;
    }

    $conn->close();
} else {
    echo "Please provide a database name.";
}
?>
