<?php
include 'db_connection.php';
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to your database (replace DB_HOST, DB_USER, DB_PASSWORD, and DB_NAME with your actual database credentials)


    // Retrieve form data
    $adminName = $_POST["admin_name"];
    $staffId = $_POST["staff_id"];
    $designation = $_POST["designation"];
    $domain = $_POST["domain"];
    $userName = $_POST["user_name"];
    $password = $_POST["password"];
    $role = $_POST["role"];
    $dbName = $_POST["db_name"];

    // Prepare and execute SQL statement to insert data into the database
    $stmt = $conn->prepare("INSERT INTO admin_table (name, staff_id, designation, domain, user_name, password, role, db_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $adminName, $staffId, $designation, $domain, $userName, $password, $role, $dbName);
    $stmt->execute();

    echo "Details inserted successfully";
    // Close the statement and the connection
    $stmt->close();
    $conn->close();

    // Redirect back to the page (adjust the URL as needed)
    header("Location: super_user.php");
    exit();
}
?>
