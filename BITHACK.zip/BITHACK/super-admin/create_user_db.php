<?php
$servername = "localhost"; // e.g., localhost
$username = "root";
$password = "";

if(isset($_POST['dbname'])) {
    $dbname = $_POST['dbname'];

    // Create connection
    $conn = new mysqli($servername, $username, $password);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS $dbname";
    if ($conn->query($sql) === TRUE) {
        header("Location: create_db.php?success=1");
        exit();
        // echo "Database $dbname created successfully<br>";
    } else {
        echo "Error creating database: " . $conn->error;
    }

    // Connect to the newly created database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create tables
    $sql_table1 = "CREATE TABLE IF NOT EXISTS attendance (
        id INT PRIMARY KEY AUTO_INCREMENT,
        team_name INT,
        student_roll VARCHAR(20),
        attendance_date Date
    )";

    $sql_table2 = "CREATE TABLE IF NOT EXISTS team_marks (
        id INT PRIMARY KEY AUTO_INCREMENT,
        team_name VARCHAR(255),
        roll_no VARCHAR(20),
        marks INT
    )";

    $sql_table3 = "CREATE TABLE IF NOT EXISTS team_attendance (
        team_name VARCHAR(255) PRIMARY KEY,
        lead_rollno VARCHAR(255) NOT NULL,
        member_1_rollno VARCHAR(255),
        member_2_rollno VARCHAR(255),
        member_3_rollno VARCHAR(255),
        member_4_rollno VARCHAR(255),
        member_5_rollno VARCHAR(255)
    )";

    $sql_table4 = "CREATE TABLE IF NOT EXISTS teams (
        team_id INT PRIMARY KEY AUTO_INCREMENT,
        team_name VARCHAR(255) NOT NULL,
        team_lead_name VARCHAR(255) NOT NULL,
        team_lead_roll VARCHAR(20) NOT NULL,
        team_lead_gender VARCHAR(10) NOT NULL,
        team_lead_phone VARCHAR(15) NOT NULL,
        team_lead_mail VARCHAR(255) NOT NULL,
        team_lead_department VARCHAR(255) NOT NULL,
        team_lead_residence VARCHAR(20) NOT NULL,
        lab_id VARCHAR(50) NOT NULL,
        lab_name VARCHAR(255) NOT NULL,
        YEAR VARCHAR(255),
        Problem_code VARCHAR(50)
    )";

    $sql_table5 = "CREATE TABLE IF NOT EXISTS team_members (
        member_id INT PRIMARY KEY AUTO_INCREMENT,
        team_id INT,
        member_name VARCHAR(255),
        member_roll VARCHAR(50),
        member_gender VARCHAR(10),
        member_phone VARCHAR(15),
        member_mail VARCHAR(255),
        member_department VARCHAR(255),
        member_residence VARCHAR(50),
        member_lab_id VARCHAR(50),
        member_lab_name VARCHAR(255),
        YEAR VARCHAR(255)
    )";

    if ($conn->query($sql_table1) === TRUE) {
        echo "Table 'table1' created successfully<br>";
    } else {
        echo "Error creating table 'table1': " . $conn->error;
    }

    if ($conn->query($sql_table2) === TRUE) {
        echo "Table 'table2' created successfully<br>";
    } else {
        echo "Error creating table 'table2': " . $conn->error;
    }

    if ($conn->query($sql_table3) === TRUE) {
        echo "Table 'table3' created successfully<br>";
    } else {
        echo "Error creating table 'table3': " . $conn->error;
    }

    if ($conn->query($sql_table4) === TRUE) {
        echo "Table 'table4' created successfully<br>";
    } else {
        echo "Error creating table 'table4': " . $conn->error;
    }

    if ($conn->query($sql_table5) === TRUE) {
        echo "Table 'table5' created successfully<br>";
    } else {
        echo "Error creating table 'table5': " . $conn->error;
    }

    $conn->close();
} else {
    echo "Please provide a database name.";
}
?>
