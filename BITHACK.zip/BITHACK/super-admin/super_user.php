<?php 
session_start();

if (isset($_SESSION['name']) &&  isset($_SESSION['user_name'])&& isset($_SESSION['role'])) {

 ?>
 <html>
    <head>
        <link rel="icon" href="logo.png" type="image/x-icon">
        <title>BIT SUPER ADMIN</title>
        
        <link rel="stylesheet" href="user.css">
        </head>
        <body>
            <div class="banner">
                <div class="navbar">
               <img src="logo.png" class="logo">
                <ul>
                    <li><a href="super_user.php">Home</a></li>
                    <li><a href="#" id="open-admin-db-modal-btn">Admin DB</a></li>
                    <li><a href="#" id="open-user-db-modal-btn">User DB</a></li>
                    <!-- <li><a href="#">Manage</a></li> -->
                    <li><a href="../login-session/logout_super.php"><?php echo $_SESSION['name']; ?></a></li>

                    <!-- <a href="index.html">
                    <button style="color:violet;"  type="button" >Logout</button></a> -->
                
                </ul>
            </div>
 
            <div id="admin-db-modal" class="modal">
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <h2>Admin Database</h2><br>
        <form action="create_admin_db.php" method="post">
       
            <label for="admin-db-name">DB Name:</label>
            <input type="text" id="admin-db-name" name="dbname" required>
            <button type="submit">Submit</button>
        </form>
    </div>
</div>

<!-- Admin Details Modal -->
<div id="admin-details-modal" class="modal">
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <h2>Admin Details</h2><br>
        <form action="admin_details_process.php" method="post">
        <label for="admin-name">Name:</label>
            <input type="text" id="admin-name" name="admin_name" required><br>
            
            <label for="admin-staff-id">Staff ID:</label>
            <input type="text" id="admin-staff-id" name="staff_id" required>

            <label for="admin-designation">Designation:</label>
            <input type="text" id="admin-designation" name="designation" required>

            <label for="admin-domain">Domain:</label>
            <input type="text" id="admin-domain" name="domain" required>

            <label for="admin-user-name">User Name:</label>
            <input type="text" id="admin-user-name" name="user_name" required>

            <label for="admin-password">Password:</label>
            <input type="password" id="admin-password" name="password" required><br>

            <label for="admin-role">Role:</label>
            <input type="text" id="admin-role" name="role" required><br>

            <label for="admin-db-name">DB Name:</label>
            <input type="text" id="admin-db-name" name="db_name" >

            <button type="submit">Submit</button>
        </form>
    </div>
</div>

<!-- User Database Modal -->
<div id="user-db-modal" class="modal">
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <h2>User Database</h2><br>
        <form action="create_user_db.php" method="post">
            <label for="user-db-name">DB Name:</label>
            <input type="text" id="user-db-name" name="db_name" required>
            <!-- Add other details as needed -->
            <button type="submit">Submit</button>
        </form>
    </div>
</div>

<!-- User Details Modal -->


            <div class="content">
                <h1>Welcome <?php echo $_SESSION['name']; ?></h1>
                <h3>SERVICE FOR SOCIETY <br>I CAN'T BUT WE CAN</h3><br><br>
                <div><a href="#">
                    <button type="button" id="open-admin-details-modal-btn"><span class="anime" ></span>Manage</button></a>
                    <!-- <a href="#">
                    <button type="button" id="open-user-details-modal-btn"><span class="anime" ></span>Create User</button></a> -->
       

            </div>

            </div>
            

    <script src="problem_model.js"></script>

            </body>
    </html>
<?php 
}else{
     header("Location: ../login-session/super_index.php");
     exit();
}
 ?>