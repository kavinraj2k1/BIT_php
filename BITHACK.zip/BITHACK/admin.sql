-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2023 at 04:34 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_display`
--

CREATE TABLE `admin_display` (
  `id` int(50) NOT NULL,
  `event_org` varchar(255) NOT NULL,
  `event_type` varchar(255) NOT NULL,
  `organizer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_display`
--

INSERT INTO `admin_display` (`id`, `event_org`, `event_type`, `organizer`) VALUES
(1, 'BIT', 'HACK 23', 'SPECIAL LABORATORIES');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notify`
--

CREATE TABLE `admin_notify` (
  `id` int(11) NOT NULL,
  `notification` varchar(255) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_notify`
--

INSERT INTO `admin_notify` (`id`, `notification`, `date_time`) VALUES
(32, 'METTING', '2023-10-04 17:20:00'),
(33, 'MEETING', '2023-10-10 09:46:00'),
(34, 'leo', '2023-10-19 22:30:00'),
(35, 'hi', '2023-11-23 11:20:00'),
(36, 'leo', '2023-11-15 08:55:00');

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE `admin_table` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `staff_id` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `db_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`id`, `name`, `staff_id`, `designation`, `domain`, `user_name`, `password`, `role`, `db_name`) VALUES
(7, 'SUDHARSAN', 'IN7144', 'INTERN', 'WEB DEVELOPMENT', 'in7144', '$2y$10$F1rm8y1XJgor43lCetD1peGUsLPYCBbvsnk/WnH2kPSm1mbqCqjtG', 'user', 'sweb'),
(6, 'VIGNESH', 'IN7147', 'INTERN', 'CLOUD COMPUTING', 'in7147', '$2y$10$mjtddE2M/.bYHmHX8eN1FOTHqZhvsaRJeyPQ5zIkwwDp.RjXyUL12', 'user', 'scloud'),
(4, 'SUDHARSAN', 'IN7148', 'INTERN', 'CLOUD COMPUTING', 'in7148', '$2y$10$cFpkTpPd.OSgejyjUsAhsOnH4cXM7RVlgf.TxKdH4rZn.ialBkdb2', 'user', 'scloud'),
(8, 'NAVEEN RAJ', 'IN7182', 'INTERN', 'CYBER SECURITY', 'in7182', '$2y$10$0F3RhTzFeNV/rnWl5MSVOeyDtMJK45jO2Z2VrMfeydAllEeZfXo/2', 'user', 'scyber'),
(5, 'KAVINRAJ', 'IN7219', 'INTERN', 'CLOUD COMPUTING', 'in7219', '$2y$10$OQfFKcHEyBQZJG.p9EQ3q.5.zdppFe2m7WNN5OwP6T14yGLRjIlo6', 'user', 'scloud'),
(3, 'NATRAJ', 'ST12', 'ASSISTANT PROFESSOR', 'CLOUD COMPUTING', 'st12', '$2y$10$YD02d5yjGnIfbs0rAg5Vu.53pIKPXfN8e1nNyvfcJSYgNg17GXm1y', 'admin', NULL),
(2, 'PURSHOTHAMAN', 'ST123', 'ASSISTANT PROFESSOR', 'ARTIFICIAL INTELEGENCE', 'st123', '$2y$10$ISDZwKNy5iVkjLBZuSBwh.EQPVRexFQnJ2gsvWRNDUpw0mJZcDOr2', 'admin', NULL),
(1, 'SUNDAR', 'ST12345', 'ASSISTANT PROFESSOR', 'SPECIAL LAB', 'st12345', '$2y$10$y1LbXaB1VaPo2uY8lLC4luBWn0FT9N5SLhvETnnh6NSgN00W9p1Ea', 'admin', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_table1`
--

CREATE TABLE `admin_table1` (
  `id` int(50) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `staff_id` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `db_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_table1`
--

INSERT INTO `admin_table1` (`id`, `name`, `staff_id`, `designation`, `domain`, `user_name`, `password`, `role`, `db_name`) VALUES
(2, 'PURSHOTHAMAN', 'ST123', 'ASSISTANT PROFESSOR', 'ARTIFICIAL INTELEGENCE', 'st123', 'purshothaman', 'admin', NULL),
(1, 'SUNDAR', 'ST12345', 'ASSISTANT PROFESSOR', 'SPECIAL LAB', 'st12345', 'sundar', 'admin', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_name` varchar(255) NOT NULL,
  `event_type` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_name`, `event_type`, `date`, `status`) VALUES
('BIT HACK\'23', 'SOFTWARE', '2023-09-30', 'APPROVED'),
('BIT HACH\'23', 'SOFTWARE', '2023-10-06', 'APPROVED'),
('hi', 'SOFTWARE', '2023-10-08', 'APPROVED'),
('BIT HACH\'23', 'SOFTWARE', '2023-10-07', 'APPROVED'),
('hi', 'SOFTWARE', '2023-10-06', 'APPROVED');

-- --------------------------------------------------------

--
-- Table structure for table `problem_statement`
--

CREATE TABLE `problem_statement` (
  `problem_code` varchar(255) NOT NULL,
  `problem_statement` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `problem_statement`
--

INSERT INTO `problem_statement` (`problem_code`, `problem_statement`, `domain`) VALUES
('CL01', 'DEPLOY A WEB APPLICATION IN HYPERVISOR', 'CLOUD COMPUTING'),
('CL02', 'CLOUD BASED ATTENDANCE MONITORING SYSTEM', 'CLOUD COMPUTING'),
('CS01', 'ENCRPTION AND DECRPTION', 'CYBER SECURITY'),
('CS02', 'ANTI VIRUS SOFTWARE', 'CYBER SECURITY'),
('CL03', 'ONLINE AUCTION AND BIDDING SYSTEM', 'CLOUD COMPUTING'),
('CS03', 'ENCRPTION AND DECRPTION FILE', 'CYBER SECURITY');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `staff_id` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`id`, `name`, `staff_id`, `designation`, `domain`, `user_name`, `password`, `role`) VALUES
(1, 'SUDHARSAN', 'IN7148', 'INTERN', 'CLOUD COMPUTING', 'in7148', 'sudhar', 'user'),
(2, 'VIGNESH', 'IN7147', 'INTERN', 'CLOUD COMPUTING', 'in7147', 'vignesh', 'user'),
(3, 'KAVINRAJ ', 'IN7219', 'INTERN', 'CLOUD COMPUTING', 'in7219', 'kavinraj', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_display`
--
ALTER TABLE `admin_display`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_notify`
--
ALTER TABLE `admin_notify`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
  ADD PRIMARY KEY (`user_name`),
  ADD UNIQUE KEY `1` (`id`);

--
-- Indexes for table `admin_table1`
--
ALTER TABLE `admin_table1`
  ADD PRIMARY KEY (`user_name`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_display`
--
ALTER TABLE `admin_display`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_notify`
--
ALTER TABLE `admin_notify`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `admin_table`
--
ALTER TABLE `admin_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
