const Orders = [
    {
        productName: 'CL01',
        productNumber: 'Deploy a Application For Job Seekers and Employees in EC2 with ELB and Auto Scaling Group with RDS',
        // paymentStatus: 'Due',
        // status: 'Pending'
    },
    {
        productName: 'CL02',
        productNumber: 'Cloud Based Attendance Monitoring System',
        // paymentStatus: 'Refunded',
        // status: 'Declined'
    },
    {
        productName: 'CL03',
        productNumber: 'Develop a Dictionary website with Email trigger',
        // paymentStatus: 'Paid',
        // status: 'Active'
    },
    {
        productName: 'CL04',
        productNumber: 'Developing an Online Auction and Bidding Platform.',
        // paymentStatus: 'Paid',
        // status: 'Active'
    },
    {
        productName: 'CL05',
        productNumber: 'Deploy a web application in Hypervisor',
        // paymentStatus: 'Paid',
        // status: 'Active'
    },
    
]