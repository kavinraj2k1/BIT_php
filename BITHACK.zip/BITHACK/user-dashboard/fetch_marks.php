<?php
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {

if (isset($_GET["rollNo"])) {
    $rollNo = $_GET["rollNo"];
    $database_name = $_SESSION['db_name']; 
    // Connect to your database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = $database_name ;

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query the database to fetch the total marks for the provided roll number
    $sql = "SELECT SUM(marks) AS marks FROM team_marks WHERE roll_no = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $rollNo); // "s" represents a string (roll number)
    $stmt->execute();
    $stmt->bind_result($marks);

    if ($stmt->fetch()) {
        
        echo $marks;
    } else {
        echo "No data found for Roll No $rollNo.";
    }

    // Close the connection
    $stmt->close();
    $conn->close();
}}
?>
