<?php 
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name']) && isset($_SESSION['event_org']) && isset($_SESSION['event_type']) && isset($_SESSION['organizer'])) {
    $database_name = $_SESSION['db_name']; 

 ?>
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Dashboard | <?php echo $_SESSION['event_org']; ?> <?php echo $_SESSION['event_type']; ?></title>
</head>

<body>


    <div class="container">
        <!-- Sidebar Section -->
        <aside>
            <div class="toggle">
                <div class="logo">
                    <img src="images/logo1.png">
                    <h2><?php echo $_SESSION['event_org']; ?><span class="danger"><?php echo $_SESSION['event_type']; ?> </span></h2>
                </div>
                <div class="close" id="close-btn">
                    <span class="material-icons-sharp">close</span>
                </div>
            </div>

            <div class="sidebar">
                <a href="userindex.php" class="active">
                    <span class="material-icons-sharp">dashboard</span>
                    <h3>Dashboard</h3>
                </a>
                <!-- <a href="#">
                    <span class="material-icons-sharp">person_outline</span>
                    <h3>Users</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">receipt_long
                    </span>
                    <h3>History</h3>
                </a> -->
                <a href="userdashboard.php" >
                    <span class="material-icons-sharp">insights</span>
                    <h3>Problem Statement</h3>
                </a>
                <!-- <a href="#">
                    <span class="material-icons-sharp">
                        mail_outline
                    </span>
                    <h3>Tickets</h3>
                    <span class="message-count">27</span>
                </a> -->
                <a href="stdlog.php">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Work Log</h3>
                </a>
                <a href="userreport.php">
                    <span class="material-icons-sharp">report_gmailerrorred</span>
                    <h3>Reports</h3>
                </a>
                <a href="stdattendance.php">
                    <span class="material-icons-sharp">
                        person_outline
                    </span>
                    <h3>Attendence</h3>
                </a>
                <a href="stdattendancereport.php">
                    <span class="material-icons-sharp">
                        receipt_long
                    </span>
                    <h3>History</h3>
                </a>
                <a href="download_details.php">
                    <span class="material-icons-sharp">
                        mail_outline
                    </span>
                    <h3>Details</h3>
                    <!-- <span class="message-count">1</span> -->
                </a>
                <a href="profile.php">
                    <span class="material-icons-sharp">settings</span>
                    <h3>Settings</h3>
                </a>
                <a href="../create-team/index.php">
                    <span class="material-icons-sharp">add</span>
                    <h3>Add Team</h3>
                </a>
                <a href="../login-session/logout.php">
                    <span class="material-icons-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <!-- End of Sidebar Section -->

        <!-- Main Content -->
        <main>
           
            <!-- End of Analyses -->
            <h2>Students</h2>
            <!-- New Users Section -->
            <div class="new-users">
      
        <div class="user-list">
        <?php
// Establish a database connection (replace with your credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = $database_name;

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    die();
}

// Initialize a variable to keep track of the total count
$totalCount = 0;

// Query the database to get the counts for each year
$years = ['I', 'II', 'III', 'IV'];

foreach ($years as $year) {
    try {
        // Query for teams count
        $stmt_teams = $conn->prepare("
            SELECT
                COUNT(*) AS team_count
            FROM
                teams
            WHERE
                YEAR = :year
        ");
        $stmt_teams->bindParam(':year', $year);
        $stmt_teams->execute();

        // Query for team_members count
        $stmt_members = $conn->prepare("
            SELECT
                COUNT(*) AS member_count
            FROM
                team_members
            WHERE
                YEAR = :year
        ");
        $stmt_members->bindParam(':year', $year);
        $stmt_members->execute();

        $result_teams = $stmt_teams->fetch(PDO::FETCH_ASSOC);
        $result_members = $stmt_members->fetch(PDO::FETCH_ASSOC);

        // Calculate the total count for this year
        $yearlyCount = ($result_teams ? $result_teams['team_count'] : 0) + ($result_members ? $result_members['member_count'] : 0);

        // Update the total count
        $totalCount += $yearlyCount;

        echo '<div class="user">
                <img src="images/profile-6.png">
                <h2>' . $year . ' YEAR</h2>
                
                <p>' . $yearlyCount . '</p>
            </div>';

           
    } catch (PDOException $e) {
        // Handle database error
        echo '<div class="user">
                <img src="images/profile-6.png">
                <h2>' . $year . ' YEAR</h2>
                <p>Database Error</p>
            </div>';
    }
}
echo '<div class="user">
<img src="images/profile-8.png">
<h2>OVERALL</h2>
<p>' . $totalCount . '</p>
</div>';
// Display the overall total count
//echo '<p>Overall Total: ' . $totalCount . '</p>';

// Close the database connection
$conn = null;
?>
        </div>
    </div><br>
            <!-- End of New Users Section -->
            <h2>Analytics</h2>
            <!-- Analyses -->
            
                        <?php
// Establish a database connection (replace with your credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = $database_name;


try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    die();
}

// Initialize variables to keep track of male and female counts
$totalMaleCount = 0;
$totalFemaleCount = 0;

// Query the database to get the counts for each year
$years = ['I', 'II', 'III', 'IV'];

foreach ($years as $year) {
    try {
        // Query to count male students
        $stmt_male = $conn->prepare("
            SELECT
                COUNT(*) AS male_count
            FROM
                teams
            WHERE
                YEAR = :year
            AND
                team_lead_gender = 'male'
        ");
        $stmt_male->bindParam(':year', $year);
        $stmt_male->execute();

        // Query to count male students from team_members table
        $stmt_male_members = $conn->prepare("
            SELECT
                COUNT(*) AS male_count
            FROM
                team_members
            WHERE
                YEAR = :year
            AND
                member_gender = 'male'
        ");
        $stmt_male_members->bindParam(':year', $year);
        $stmt_male_members->execute();

        // Query to count female students
        $stmt_female = $conn->prepare("
            SELECT
                COUNT(*) AS female_count
            FROM
                teams
            WHERE
                YEAR = :year
            AND
                team_lead_gender = 'female'
        ");
        $stmt_female->bindParam(':year', $year);
        $stmt_female->execute();

        // Query to count female students from team_members table
        $stmt_female_members = $conn->prepare("
            SELECT
                COUNT(*) AS female_count
            FROM
                team_members
            WHERE
                YEAR = :year
            AND
                member_gender = 'female'
        ");
        $stmt_female_members->bindParam(':year', $year);
        $stmt_female_members->execute();

        // Fetch and calculate male and female counts for this year
        $result_male = $stmt_male->fetch(PDO::FETCH_ASSOC);
        $result_male_members = $stmt_male_members->fetch(PDO::FETCH_ASSOC);
        $result_female = $stmt_female->fetch(PDO::FETCH_ASSOC);
        $result_female_members = $stmt_female_members->fetch(PDO::FETCH_ASSOC);

        // Calculate the total male and female count for this year
        $maleCount = ($result_male ? $result_male['male_count'] : 0) + ($result_male_members ? $result_male_members['male_count'] : 0);
        $femaleCount = ($result_female ? $result_female['female_count'] : 0) + ($result_female_members ? $result_female_members['female_count'] : 0);

        // Update the total male and female counts
        $totalMaleCount += $maleCount;
        $totalFemaleCount += $femaleCount;

    } catch (PDOException $e) {
        // Handle database error
        echo '<div class="user">
                <img src="images/profile-6.png">
                <h2>' . $year . ' YEAR</h2>
                <p>Database Error</p>
            </div>';
    }
}

try {
    // Query to count the number of teams
    $stmt_team_count = $conn->prepare("SELECT COUNT(*) AS team_count FROM teams");
    $stmt_team_count->execute();
    
    // Fetch the team count
    $result_team_count = $stmt_team_count->fetch(PDO::FETCH_ASSOC);
    
    // Display the team count
    $teamCount = $result_team_count['team_count'];
   // echo "Total number of teams: " . $teamCount;
} catch (PDOException $e) {
    // Handle database error
    echo "Database Error: " . $e->getMessage();
}

// Close the database connection
$conn = null;
?>
<div class="analyse">
                <div class="sales">
                    <div class="status">
                        <div class="info">
                            <h3>TEAMS</h3>
                            <h1><?php echo ' ' . $teamCount . '';?></h1>
                        </div>
                        <div class="progresss">
                            <svg>
                                <circle cx="38" cy="38" r="36"></circle>
                            </svg>
                            <div class="percentage">
                                <p>Teams</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="searches">
                    <div class="status">
                        <div class="info">
                            <h3>MALE</h3>
                            <h1><?php echo ' ' . $totalMaleCount . '';?></h1>
                        </div>
                        <div class="progresss">
                            <svg>
                                <circle cx="38" cy="38" r="36"></circle>
                            </svg>
                            <div class="percentage">
                                <p>Boys</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="visits">
                    <div class="status">
                        <div class="info">
                            <h3>FEMALE</h3>
                            <h1><?php echo ' ' .$totalFemaleCount . '';?></h1>
                        </div>
                        <div class="progresss">
                            <svg>
                                <circle cx="38" cy="38" r="36"></circle>
                            </svg>
                            <div class="percentage">
                                <p>Girls</p>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div><br>
            <!-- Recent Orders Table -->
            <h2>Genders</h2>
            <!-- New Users Section -->
            <div class="new-users">
      
        <div class="user-list">
        <?php
// Establish a database connection (replace with your credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = $database_name;

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    die();
}

// Initialize variables to keep track of male and female counts
$totalMaleCount = 0;
$totalFemaleCount = 0;

// Query the database to get the counts for each year
$years = ['I', 'II', 'III', 'IV'];

foreach ($years as $year) {
    try {
        // Query to count male students
        $stmt_male = $conn->prepare("
            SELECT
                COUNT(*) AS male_count
            FROM
                teams
            WHERE
                YEAR = :year
            AND
                team_lead_gender = 'male'
        ");
        $stmt_male->bindParam(':year', $year);
        $stmt_male->execute();

        // Query to count male students from team_members table
        $stmt_male_members = $conn->prepare("
            SELECT
                COUNT(*) AS male_count
            FROM
                team_members
            WHERE
                YEAR = :year
            AND
                member_gender = 'male'
        ");
        $stmt_male_members->bindParam(':year', $year);
        $stmt_male_members->execute();

        // Query to count female students
        $stmt_female = $conn->prepare("
            SELECT
                COUNT(*) AS female_count
            FROM
                teams
            WHERE
                YEAR = :year
            AND
                team_lead_gender = 'female'
        ");
        $stmt_female->bindParam(':year', $year);
        $stmt_female->execute();

        // Query to count female students from team_members table
        $stmt_female_members = $conn->prepare("
            SELECT
                COUNT(*) AS female_count
            FROM
                team_members
            WHERE
                YEAR = :year
            AND
                member_gender = 'female'
        ");
        $stmt_female_members->bindParam(':year', $year);
        $stmt_female_members->execute();

        // Fetch and calculate male and female counts for this year
        $result_male = $stmt_male->fetch(PDO::FETCH_ASSOC);
        $result_male_members = $stmt_male_members->fetch(PDO::FETCH_ASSOC);
        $result_female = $stmt_female->fetch(PDO::FETCH_ASSOC);
        $result_female_members = $stmt_female_members->fetch(PDO::FETCH_ASSOC);

        // Calculate the total male and female count for this year
        $maleCount = ($result_male ? $result_male['male_count'] : 0) + ($result_male_members ? $result_male_members['male_count'] : 0);
        $femaleCount = ($result_female ? $result_female['female_count'] : 0) + ($result_female_members ? $result_female_members['female_count'] : 0);

        // Update the total male and female counts
        $totalMaleCount += $maleCount;
        $totalFemaleCount += $femaleCount;

        echo '<div class="user">
                <img src="images/profile-6.png">
                <h2>' . $year . ' YEAR</h2>
                <h4>Male : ' . $maleCount . '</h4>
                <h4>Female : ' . $femaleCount . '</h4>
            </div>';
    } catch (PDOException $e) {
        // Handle database error
        echo '<div class="user">
                <img src="images/profile-6.png">
                <h2>' . $year . ' YEAR</h2>
                <p>Database Error</p>
            </div>';
    }
}

// // Display the overall total male and female counts
// echo '<p>Overall Total Male Students: ' . $totalMaleCount . '</p>';
// echo '<p>Overall Total Female Students: ' . $totalFemaleCount . '</p>';

// Close the database connection
$conn = null;
?>

        </div>
    </div><br>
            <!-- End of Recent Orders -->

        </main>
        <!-- End of Main Content -->

        <!-- Right Section -->
        <div class="right-section">
            <div class="nav">
                <button id="menu-btn">
                    <span class="material-icons-sharp">
                        menu
                    </span>
                </button>
                <div class="dark-mode">
                    <span class="material-icons-sharp active">
                        light_mode
                    </span>
                    <span class="material-icons-sharp">
                        dark_mode
                    </span>
                </div>

                <div class="profile">
                    <div class="info">
                        <p>Hey, <b><?php echo $_SESSION['name']; ?></b></p>
                        <small class="text-muted"><?php echo $_SESSION['role']; ?></small>
                    </div>
                    <div class="profile-photo">
                        <img src="images/profile-1.jpg">
                    </div>
                </div>

            </div>
            <!-- End of Nav -->
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    die();
}

// Initialize variables to store the last notification and its date and time
$lastNotification = "";
$lastDateTime = "";

// Query to fetch the last notification and its date and time from the database
try {
    $stmt_last_notification = $conn->prepare("
        SELECT
            notification,
            date_time
        FROM
            admin_notify
        ORDER BY
            id DESC
        LIMIT 1
    ");
    $stmt_last_notification->execute();

    // Fetch the last notification and its date and time
    $lastNotificationRow = $stmt_last_notification->fetch(PDO::FETCH_ASSOC);
    
    if ($lastNotificationRow) {
        $lastNotification = $lastNotificationRow['notification'];
        $lastDateTime = $lastNotificationRow['date_time'];
    }
} catch (PDOException $e) {
    // Handle database error for fetching the last notification
    echo '<p class="notification">Error fetching the last notification</p>';
}

// Close the database connection
$conn = null;

// Display the last notification and its date and time
// echo '<div class="last-notification">';
// if (!empty($lastNotification)) {
//     echo '<p class="notification">' . $lastNotification . '</p>';
//     echo '<p class="datetime">Date and Time: ' . $lastDateTime . '</p>';
// } else {
//     echo '<p class="notification">No notifications found</p>';
// }
// echo '</div>';
?>



            <div class="user-profile">
                <div class="logo">
                    <img src="images/logo1.png">
                    <h2><?php echo $_SESSION['event_org']; ?> <?php echo $_SESSION['event_type']; ?></h2>
                    <p><?php echo $_SESSION['organizer']; ?></p>
                </div>
            </div>

            <div class="reminders">
                <div class="header">
                    <h2>Reminders</h2> 
                    <!-- <span class="message-count">1</span> -->
                    <span class="material-icons-sharp">notifications_none</span> 
                </div>
                <div class="notification" >
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                        
                    </div>
                    <div class="content" id="blink">
                        <div class="info" >
                            <h3><?php echo ' ' . $lastNotification . '';?></h3>
                            <small class="text_muted"><?php echo ' ' . $lastDateTime . '';?> </small>
                            
                        </div>
                    </div>
                </div>
                    <div class="notification" >
                    <div class="icon">
                        <span></span>
                            <img src="https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif" alt="Simple Animation" height="30px" witdh="400px">
                        
                    </div>
                    <div class="content">
                        <div class="info" >
                          <a href="#" > <h2>UPCOMMINGS....</h2></a>
                            
                        </div>
                <!-- <marquee behavior="scroll" direction="up" scrollamount="2">
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">
                            volume_up
                        </span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">
                                08:00 AM - 12:00 PM
                            </small>
                        </div>
                        <span class="material-icons-sharp">
                            more_vert
                        </span>
                    </div>
                </div>
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">
                            volume_up
                        </span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">
                                08:00 AM - 12:00 PM
                            </small>
                        </div>
                        <span class="material-icons-sharp">
                            more_vert
                        </span>
                    </div>
                </div>
                <div class="notification deactive">
                    <div class="icon">
                        <span class="material-icons-sharp">
                            edit
                        </span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">
                                08:00 AM - 12:00 PM
                            </small>
                        </div>
                        <span class="material-icons-sharp">
                            more_vert
                        </span>
                    </div>
                </div></marquee> -->

                <!-- <div class="notification add-reminder">
                    <div>
                        <span class="material-icons-sharp">
                            add
                        </span>
                        <h3>Add Reminder</h3>
                    </div>
                </div> -->

            </div>

        </div>
       
                    <div class="content" id="blink">
                        <!-- <div class="info" >
                            <h3><?php echo ' ' . $lastNotification . '';?></h3>
                            <small class="text_muted"><?php echo ' ' . $lastDateTime . '';?> </small>
                            
                        </div> -->

       
    </div>
  
    <script src="blink.js"></script>
    <script src="orders.js"></script>
    <script src="index.js"></script>
</body>

</html>
<?php 
}else{
     header("Location: ../login-session/index.php");
     exit();
}
 ?>