function updateProgressBar(value) {
    var progressBar = document.getElementById("progress");
    var progressLabel = document.getElementById("progress-label");
    progressBar.style.width = value + "%";
    progressLabel.innerText = value + "%";
}
