// Get references to the select elements
const stateSelect = document.getElementById("stateSelect");
const districtSelect = document.getElementById("districtSelect");

// District data for each state
const districtData = {
    SLB082: ["CLOUD COMPUTING - SOFTWARE SERVICES"],
    SLB008: ["CLOUD COMPUTING - INFRASTRUCTURE SERVICES"],
    SLB068: ["DATA SCIENCE - COMPUTATIONAL INTELLIGENCE"],
    SLB002: ["DATA SCIENCE - INDUSTRIAL APPLICATIONS"]
};

// Function to populate districts based on selected state
function populateDistricts() {
    const selectedState = stateSelect.value;
    const districts = districtData[selectedState] || [];

    // Clear existing options
    // districtSelect.innerHTML = "<option>Choose District..</option>";

    // Populate district options
    districts.forEach(district => {
        const option = document.createElement("option");
        option.value = district;
        option.textContent = district;
        districtSelect.appendChild(option);
    });
}

// Event listener for state select change
stateSelect.addEventListener("change", populateDistricts);

// Initial population of districts
populateDistricts();






const addButton = document.getElementById("addMemberButton");
const membersForm = document.getElementById("membersForm");
const teamForm = document.getElementById("teamForm");
let memberCount = 1;

addButton.addEventListener("click", function() {
    const memberForm = document.createElement("div");
    memberForm.innerHTML = `
        <h2>Member ${memberCount}</h2>
        <label>
            Name
            <input type="text" name="memberName${memberCount}" placeholder="Enter name">
        </label>
        <label>
            Roll no
            <input type="text" name="memberRollNo${memberCount}" placeholder="Enter roll number">
        </label>
        <label>
            Email
            <input type="text" name="memberEmail${memberCount}" placeholder="Enter email">
        </label>
        <label>
            Department
            <input type="text" name="memberDepartment${memberCount}" placeholder="Enter department">
        </label>
        <label>
            Phone No
            <input type="text" name="memberPhone${memberCount}" placeholder="Enter phone no">
        </label>
        <label>
            Hosteller/Dayscholar
            <input type="text" name="memberHostellerDayscholar${memberCount}" placeholder="Enter hosteller/dayscholar">
        </label>
        <div id="zip1">
            <label>
                Lab Id
                <select name="memberLabId${memberCount}">
                    <option>Choose Lab Id..</option>
                    <option value="SLB082">SLB082</option>
                    <option value="SLB008">SLB008</option>
                    <option value="SLB068">SLB068</option>
                    <option value="SLB002">SLB002</option>
                </select>
            </label>
            <label>
                Lab Name
                <select name="memberLabName${memberCount}">
                    <!-- <option>Choose District..</option> -->
                </select>
            </label>
        </div>
        <hr>
    `;
    membersForm.appendChild(memberForm);
    memberCount++;
});

teamForm.addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission for now
    // Here you can gather all the form data and send it to the server using AJAX or other methods
    // Example:
    const formData = new FormData(teamForm);
    // Now you can process the formData object and send it to the server
});




$(document).ready(function() {
    $("#team_name").change(function() {
        var selectedTeam = $(this).val();

        if (selectedTeam !== "") {
            $.ajax({
                type: "POST",
                url: "fetch_team_details.php",
                data: { team_name: selectedTeam },
                success: function(response) {
                    $("#team_details").html(response);
                }
            });
        } else {
            $("#team_details").empty();
        }
    });
});



// script.js

// Function to update the progress bar based on student marks
function updateProgressBar(marks) {
    const progressBar = document.getElementById("progress");
    progressBar.style.width = `${marks}%`;
    progressBar.innerText = `${marks}%`;
}

// Function to get the student's marks from the input field and update the progress bar
function updateProgress() {
    const marksInput = document.getElementById("marksInput");
    const studentMarks = parseInt(marksInput.value, 10); // Parse input value as an integer
    if (!isNaN(studentMarks) && studentMarks >= 0 && studentMarks <= 500) {
        updateProgressBar(studentMarks);
    } else {
        alert("Please enter valid marks between 0 and 100.");
    }
}
