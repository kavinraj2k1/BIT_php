<?php
session_start();

if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {
    $database_name = $_SESSION['db_name'];

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection parameters
        $servername = "localhost";  // Change this if your database is on a different server
        $username = "root";
        $password = "";
        $dbname = $database_name;

        // Create a connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Data from the form
        // Data from the form
        $teamName = $_POST["teamName"];
        $leadRole = $_POST["leadRole"];
        $currentDate = date("Y-m-d"); // Assuming your date column in the database is of type DATE

        $sql = "SELECT * FROM attendance WHERE student_roll = '$leadRole' AND attendance_date = '$currentDate'";
        $result = $conn->query($sql);


        if ($result->num_rows > 0) {
            // echo "Attendance already recorded for roll number $leadRole on $currentDate.";
            header("Location: stdattendance.php?error=Attendance already recorded for roll number $leadRole on $currentDate.");
            exit();
        } else {
            // Insert the data into the database
            $stmt = $conn->prepare("INSERT INTO attendance (team_name, student_roll, attendance_date) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $teamName, $leadRole, $currentDate);

            if ($stmt->execute()) {
                // echo "Record added successfully!";
                header("Location: stdattendance.php?success=1");
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        }
        $conn->close();
    }
}
?>
