<?php
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {
    $database_name = $_SESSION['db_name']; 
// Step 1: Connect to the Database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = $database_name;

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Get User Input
$date = $_POST['date'];

// Step 3: Execute SQL Query to Count Roll Numbers
$sql = "SELECT COUNT(*) AS count FROM attendance WHERE attendance_date = '$date'";
$result = $conn->query($sql);

// Step 4: Fetch and Display Count
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // echo "Total Students Count on $date : " . $row["count"];
    header("Location: stdattendancereport.php?error=Total Students Count on $date : " . $row["count"]);
    exit();
} else {
    // echo "0 results";
    header("Location: stdattendancereport.php?error= 0 results for this date");
    exit();
}

$conn->close();
}
?>
