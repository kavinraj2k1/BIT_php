<?php 
session_start();

if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {
   
    // Define database names based on domain and role
    $database_name = $_SESSION['db_name']; 

   

    if ($database_name !== '') {
        $connection = mysqli_connect("localhost", "root", "", $database_name);

        if (!$connection) {
            die("Connection failed: " . mysqli_connect_error());
        }

$query = "SELECT team_id, team_name FROM teams";
$result = mysqli_query($connection, $query);

$teams = array();
while ($row = mysqli_fetch_assoc($result)) {
    $teams[$row['team_id']] = $row['team_name'];
}

mysqli_close($connection);
?>
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Dashboard | BIT HACK'23</title>
</head>

<body>
<div class="container">
        <!-- Sidebar Section -->
        <aside>
            <div class="toggle">
                <div class="logo">
                    <img src="images/logo1.png">
                    <h2>BIT<span class="danger">HACK'23 </span></h2>
                </div>
                <div class="close" id="close-btn">
                    <span class="material-icons-sharp">close</span>
                </div>
            </div>

            <div class="sidebar">
                <a href="userindex.php" >
                    <span class="material-icons-sharp">dashboard</span>
                    <h3>Dashboard</h3>
                </a>
                <!-- <a href="#">
                    <span class="material-icons-sharp">person_outline</span>
                    <h3>Users</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">receipt_long
                    </span>
                    <h3>History</h3>
                </a> -->
                <a href="userdashboard.php" >
                    <span class="material-icons-sharp">insights</span>
                    <h3>Problem Statement</h3>
                </a>
                <!-- <a href="#">
                    <span class="material-icons-sharp">
                        mail_outline
                    </span>
                    <h3>Tickets</h3>
                    <span class="message-count">27</span>
                </a> -->
                <a href="stdlog.php" class="active">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Work Log</h3>
                </a>
                <a href="userreport.php">
                    <span class="material-icons-sharp">report_gmailerrorred</span>
                    <h3>Reports</h3>
                </a>
                <a href="stdattendance.php">
                    <span class="material-icons-sharp">
                        person_outline
                    </span>
                    <h3>Attendence</h3>
                </a>
                <a href="stdattendancereport.php">
                    <span class="material-icons-sharp">
                        receipt_long
                    </span>
                    <h3>History</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">
                        mail_outline
                    </span>
                    <h3>Notification</h3>
                    <span class="message-count">1</span>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">settings</span>
                    <h3>Settings</h3>
                </a>
                <a href="../create-team/index.php">
                    <span class="material-icons-sharp">add</span>
                    <h3>Add Team</h3>
                </a>
                <a href="../login-session/logout.php">
                    <span class="material-icons-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <!-- End of Sidebar Section -->

        <!-- Main Content -->
        <main>
                       <!-- Recent Orders Table -->
                       <div class="new-users">
                <h2>Work Log</h2>
                <div class="user-list">
                    <div class="user">
                        <!-- <form >
                            <label > Team name</label>
                            <input type="text"><br>
                            <label >Enter Mark</label>
                            <input type="text"><br>
                            
                        </form><form action="selected_team.php" method="post"> -->
                        <form method="post" action="insert.php">        
        <label for="team_selection">Select a Team:</label>
        <select name="teamName" id="team_selection" required>
        <option>Choose Team..</option>
            <?php foreach ($teams as $team_id => $team_name) { ?>
                <option value="<?php echo $team_id; ?>"><?php echo $team_name; ?></option>
            <?php } ?>
        </select>
        <!-- <label >Team Name</label>
                            <input type="text" name="teamName" id="team_name" placeholder="Team Name" required> -->
        <br><br><label >Lead Roll No</label>
                            <input type="text" name="leadRole" id="roll_no" placeholder="Roll no" required>
        <br><br><label >Enter Mark</label>
                            <input type="text" name="marks" id="marks" placeholder="Mark" required><br><br>
        <input type="submit" value="Submit">
    </form>
                </div>
            </div>
            <!-- End of Recent Orders -->

        </main>
        <!-- End of Main Content -->

        <!-- Right Section -->
        <div class="right-section">
            <div class="nav">
                <button id="menu-btn">
                    <span class="material-icons-sharp">
                        menu
                    </span>
                </button>
                <div class="dark-mode">
                    <span class="material-icons-sharp active">
                        light_mode
                    </span>
                    <span class="material-icons-sharp">
                        dark_mode
                    </span>
                </div>

                <div class="profile">
                    <div class="info">
                        <p>Hey, <b><?php echo $_SESSION['name']; ?></b></p>
                        <small class="text-muted"><?php echo $_SESSION['role']; ?></small>
                    </div>
                    <div class="profile-photo">
                        <img src="images/profile-1.jpg">
                    </div>
                </div>

            </div>
            <!-- End of Nav -->
            <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    die();
}

// Initialize variables to store the last notification and its date and time
$lastNotification = "";
$lastDateTime = "";

// Query to fetch the last notification and its date and time from the database
try {
    $stmt_last_notification = $conn->prepare("
        SELECT
            notification,
            date_time
        FROM
            admin_notify
        ORDER BY
            id DESC
        LIMIT 1
    ");
    $stmt_last_notification->execute();

    // Fetch the last notification and its date and time
    $lastNotificationRow = $stmt_last_notification->fetch(PDO::FETCH_ASSOC);
    
    if ($lastNotificationRow) {
        $lastNotification = $lastNotificationRow['notification'];
        $lastDateTime = $lastNotificationRow['date_time'];
    }
} catch (PDOException $e) {
    // Handle database error for fetching the last notification
    echo '<p class="notification">Error fetching the last notification</p>';
}

// Close the database connection
$conn = null;

// Display the last notification and its date and time
// echo '<div class="last-notification">';
// if (!empty($lastNotification)) {
//     echo '<p class="notification">' . $lastNotification . '</p>';
//     echo '<p class="datetime">Date and Time: ' . $lastDateTime . '</p>';
// } else {
//     echo '<p class="notification">No notifications found</p>';
// }
// echo '</div>';
?>
            <div class="user-profile">
                <div class="logo">
                    <img src="images/logo1.png">
                    <h2>BIT HACK'23</h2>
                    <p>SPECIAL LABORATORIES</p>
                </div>
            </div>

            <div class="reminders">
                <div class="header">
                    <h2>Students</h2>
                    <span class="material-icons-sharp">
                        notifications_none
                    </span>
                </div>
                <a href="https://bip.bitsathy.ac.in/nova/resources/student-work-logs">
                <div class="notification deactive">
                    <div class="icon">
                        <span class="material-icons-sharp">edit</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Submit Students Log</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div></a>

                <!-- <div class="notification add-reminder">
                    <div>
                        <span class="material-icons-sharp">
                            add
                        </span>
                        <h3>Add Reminder</h3>
                    </div>
                </div> -->

            </div>

        </div>


    </div>

    <script src="orders.js"></script>
    <script src="index.js"></script>
</body>

</html>
<?php 
} else {
    die("Invalid domain or role");
}
} else {
header("Location: index.php");
exit();
}
?>