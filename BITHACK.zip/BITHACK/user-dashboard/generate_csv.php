<?php
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {

    $database_name = $_SESSION['db_name']; 
    // Connect to your database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = $database_name ;

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$gender = $_POST['gender'];
$year = $_POST['year'];
$residence = $_POST['residence'];

$sql = "SELECT 
            teams.team_name, 
            teams.team_lead_name, 
            teams.team_lead_roll, 
            teams.team_lead_gender, 
            teams.team_lead_phone, 
            teams.team_lead_mail, 
            teams.team_lead_department, 
            teams.team_lead_residence, 
            teams.lab_id, 
            teams.lab_name, 
            teams.YEAR,
            team_members.member_name, 
            team_members.member_roll, 
            team_members.member_gender, 
            team_members.member_phone, 
            team_members.member_mail, 
            team_members.member_department, 
            team_members.member_residence, 
            team_members.member_lab_id, 
            team_members.member_lab_name, 
            team_members.YEAR
        FROM teams 
        INNER JOIN team_members ON teams.team_id = team_members.team_id";

if ($gender != 'all') {
    $sql .= " WHERE teams.team_lead_gender = '$gender' 
              AND team_members.member_gender = '$gender'";
}

if ($year != 'all') {
    $sql .= " AND teams.YEAR = '$year' 
              AND team_members.YEAR = '$year'";
}

if ($residence != 'all') {
    $sql .= " AND teams.team_lead_residence = '$residence' 
              AND team_members.member_residence = '$residence'";
}

$result = $conn->query($sql);

$csvContent = "Team Name, Team Lead Name, Team Lead Roll, Team Lead Gender, Team Lead Phone, Team Lead Mail, Team Lead Department, Team Lead Residence, Lab ID, Lab Name, Year, Member Name, Member Roll, Member Gender, Member Phone, Member Mail, Member Department, Member Residence, Member Lab ID, Member Lab Name, Member Year\n";

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $csvContent .= $row["team_name"] . ", " . 
                       $row["team_lead_name"] . ", " . 
                       $row["team_lead_roll"] . ", " . 
                       $row["team_lead_gender"] . ", " . 
                       $row["team_lead_phone"] . ", " . 
                       $row["team_lead_mail"] . ", " . 
                       $row["team_lead_department"] . ", " . 
                       $row["team_lead_residence"] . ", " . 
                       $row["lab_id"] . ", " . 
                       $row["lab_name"] . ", " . 
                       $row["YEAR"] . ", " .
                       $row["member_name"] . ", " . 
                       $row["member_roll"] . ", " . 
                       $row["member_gender"] . ", " . 
                       $row["member_phone"] . ", " . 
                       $row["member_mail"] . ", " . 
                       $row["member_department"] . ", " . 
                       $row["member_residence"] . ", " . 
                       $row["member_lab_id"] . ", " . 
                       $row["member_lab_name"] . ", " . 
                       $row["YEAR"] . "\n";
    }
} else {
    echo "0 results";
}

header('Content-Type: application/csv');
header('Content-Disposition: attachment; filename=student_details.csv');
echo $csvContent;

$conn->close();
}
?>
