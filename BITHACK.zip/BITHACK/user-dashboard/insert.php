<?php
 session_start();
 if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    // $servername = "localhost";  // Change this if your database is on a different server
    // $username = "root676760";
    // $password = "123321";
    // $dbname = "students";

    // // Create a connection
    // $conn = new mysqli($servername, $username, $password, $dbname);

    // // Check the connection
    // if ($conn->connect_error) {
    //     die("Connection failed: " . $conn->connect_error);
    // }
   


    // Get domain and role from session
    // $domain = $_SESSION['domain'];
    // $role = $_SESSION['role'];

    // Define database names based on domain and role
    $database_name = $_SESSION['db_name']; 

    // if ($domain == 'example1.com') {
    //     if ($role == 'admin') {
    //         $database_name = 'database_example1_admin';
    //     } else {
    //         $database_name = 'database_example1_user';
    //     }
    // } elseif ($domain == 'example2.com') {
    //     if ($role == 'admin') {
    //         $database_name = 'database_example2_admin';
    //     } else {
    //         $database_name = 'database_example2_user';
    //     }
    // }

    if ($database_name !== '') {
        $conn = mysqli_connect("localhost", "root", "", $database_name);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

    // Data from the form
    $teamName = $_POST["teamName"];
    $leadRole = $_POST["leadRole"];
    $marks = $_POST["marks"];

    // SQL query to insert data
    $sql = "INSERT INTO team_marks (team_name, roll_no, marks) VALUES (?, ?, ?)";

    // Prepare and execute the statement
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssi", $teamName, $leadRole, $marks);

        if ($stmt->execute()) {
            // echo "Data inserted successfully.";
            header("Location: stdlog.php?success=1");
            exit();
            //form("location: stdlog.php");
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error: " . $conn->error;
    }

    // Close the connection
    $conn->close();
}
} else {
    die("Invalid domain or role");
}
} else {
header("Location: ../login-session/index.php");
exit();
}
?>
