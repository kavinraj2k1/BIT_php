<?php
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {
    $domain_name = $_SESSION['domain']; 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM problem_statement WHERE domain= '$domain_name'"; // Replace 'your_table_name' with the actual table name

$result = $conn->query($sql);

$data = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($data);
}
?>
