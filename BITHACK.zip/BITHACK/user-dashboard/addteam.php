<?php 
session_start();

if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation'])&& isset($_SESSION['domain'])&& isset($_SESSION['user_name'])&& isset($_SESSION['role'])) {

 ?>
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Dashboard | BIT HACK'23</title>
</head>

<body>

    <div class="container">
        <!-- Sidebar Section -->
        <aside>
            <div class="toggle">
                <div class="logo">
                    <img src="images/logo1.png">
                    <h2>BIT<span class="danger">HACK'23 </span></h2>
                </div>
                <div class="close" id="close-btn">
                    <span class="material-icons-sharp">close</span>
                </div>
            </div>

            <div class="sidebar">
                <a href="userdashboard.php">
                    <span class="material-icons-sharp">dashboard</span>
                    <h3>Dashboard</h3>
                </a>
                <!-- <a href="#">
                    <span class="material-icons-sharp">person_outline</span>
                    <h3>Users</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">receipt_long
                    </span>
                    <h3>History</h3>
                </a> -->
                <a href="userindex.php" >
                    <span class="material-icons-sharp">insights</span>
                    <h3>Analytics</h3>
                </a>
                <!-- <a href="#">
                    <span class="material-icons-sharp">
                        mail_outline
                    </span>
                    <h3>Tickets</h3>
                    <span class="message-count">27</span>
                </a> -->
                <a href="stdlog.php">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Work Log</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">report_gmailerrorred</span>
                    <h3>Reports</h3>
                </a>
                <a href="profile.php">
                    <span class="material-icons-sharp">settings</span>
                    <h3>Settings</h3>
                </a>
                <a href="addteam.php" class="active">
                    <span class="material-icons-sharp">add</span>
                    <h3>Add Team</h3>
                </a>
                <a href="../login-session/logout.php">
                    <span class="material-icons-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <!-- End of Sidebar Section -->

        <!-- Main Content -->
        <main>
        <div class="new-users1">
                    <h2>Create Team</h2>
                    <div class="user-list1">
                        <div class="user1">
                            <div class="container1">
                                <div class="left1">
                                    <h2>Team Details</h2>
                                    <form id="teamForm">
                                        <label>
                                            Team Name
                                            <input type="text" name="teamName" placeholder="Enter name">
                                        </label>
                                        <label>
                                            Lead Roll No
                                            <input type="text" name="leadRollNo" placeholder="Enter roll no">
                                        </label>
                                        <label>
                                            Lead Email Id
                                            <input type="text" name="leadEmail" placeholder="Enter email">
                                        </label>
                                        <label>
                                            Lead Department
                                            <input type="text" name="leadDepartment" placeholder="Enter department">
                                        </label>
                                        <label>
                                            Lead Phone No
                                            <input type="text" name="leadPhone" placeholder="Enter phone no">
                                        </label>
                                        <label>
                                            Hosteller/Dayscholar
                                            <input type="text" name="hostellerDayscholar" placeholder="Enter hosteller/dayscholar">
                                        </label>
                                        <div id="zip1">
                                            <label>
                                                Lead Lab Id
                                                <select name="leadLabId">
                                                    <option>Choose Lab Id..</option>
                                                    <option value="SLB082">SLB082</option>
                                                    <option value="SLB008">SLB008</option>
                                                    <option value="SLB068">SLB068</option>
                                                    <option value="SLB002">SLB002</option>
                                                </select>
                                            </label>
                                            <label>
                                                Lead Lab Name
                                                <select name="leadLabName">
                                                    <!-- <option>Choose District..</option> -->
                                                </select>
                                            </label>
                                        </div>
                                    </form>
                                </div>
                                <div class="right1">
                                    <h2>Members</h2>
                                    <form id="membersForm">
                                        <!-- Dynamically added member input fields will be inserted here -->
                                    </form>
                                    <button id="addMemberButton">Add Member</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        </main>
        <!-- End of Main Content -->

        <!-- Right Section -->
      
                
            <!-- End of Nav -->

            

    <script src="orders.js"></script>
    <script src="index.js"></script>
    <script src="script.js"></script>
</body>

</html>
<?php 
}else{
     header("Location: ../login-session/index.php");
     exit();
}
 ?>