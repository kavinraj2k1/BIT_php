<?php
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {
    $database_name = $_SESSION['db_name']; 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedTeam = $_POST["team_name"];

    // Establish a database connection (adjust connection details as needed)
    $connection = mysqli_connect("localhost", "root", "",  $database_name);

    if ($connection) {
        // Retrieve team details from the teams table
        $teamQuery = "SELECT * FROM teams WHERE team_name = '$selectedTeam'";
        $teamResult = mysqli_query($connection, $teamQuery);

        if ($teamResult) {
            $teamRow = mysqli_fetch_assoc($teamResult);

            if ($teamRow) {
                // Display team details (customize this part)
                echo "<h2>Team Details for $selectedTeam</h2> ";
                echo "<p>Team Lead: " . $teamRow["team_lead_name"] . "</p>";
                echo "<p>Lab ID: " . $teamRow["lab_id"] . "</p>";
                echo "<p>Team ID: " . $teamRow["team_id"] . "</p>";
                echo("Location: stdlog.php?team_id=" . $team_data['team_id']);
                // Retrieve team members from the team_members table
                $teamid= $teamRow["team_id"] ;
                $membersQuery = "SELECT * FROM team_members WHERE team_id = '$teamid'";
                $membersResult = mysqli_query($connection, $membersQuery);

                if ($membersResult) {
                    echo "<h3>Team Members:</h3>";
                    echo "<ul>";

                    while ($memberRow = mysqli_fetch_assoc($membersResult)) {
                        echo "<li>" . $memberRow["member_name"] . "</li>";
                    }

                    echo "</ul>";
                }
                // Add more details as needed
            } else {
                echo "<p>No details found for the selected team.</p>";
            }
        } else {
            echo "Error: " . mysqli_error($connection);
        }

        mysqli_close($connection);
    }
}
}
?>
