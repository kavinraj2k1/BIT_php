-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2023 at 04:36 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scloud`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `team_name` int(11) DEFAULT NULL,
  `student_roll` varchar(20) DEFAULT NULL,
  `attendance_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `team_name`, `student_roll`, `attendance_date`) VALUES
(7, 0, '191cs298', '2023-10-07'),
(8, 0, '192cb130', '2023-10-07'),
(9, 0, '191cs298', '2023-10-08'),
(10, 1, '191cs298', '2023-10-12'),
(11, 1, '192cb130', '2023-10-12'),
(12, 0, '191cs298', '2023-10-13'),
(13, 3, '192cb130', '2023-10-13'),
(14, 1, '122', '2023-10-13'),
(15, 1, '191cs298', '2023-10-14'),
(16, 1, '191cs298', '2023-11-15');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `team_id` int(11) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `team_lead_name` varchar(255) NOT NULL,
  `team_lead_roll` varchar(20) NOT NULL,
  `team_lead_gender` varchar(10) NOT NULL,
  `team_lead_phone` varchar(15) NOT NULL,
  `team_lead_mail` varchar(255) NOT NULL,
  `team_lead_department` varchar(255) NOT NULL,
  `team_lead_residence` varchar(20) NOT NULL,
  `lab_id` varchar(50) NOT NULL,
  `lab_name` varchar(255) NOT NULL,
  `YEAR` varchar(255) DEFAULT NULL,
  `Problem_code` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`team_id`, `team_name`, `team_lead_name`, `team_lead_roll`, `team_lead_gender`, `team_lead_phone`, `team_lead_mail`, `team_lead_department`, `team_lead_residence`, `lab_id`, `lab_name`, `YEAR`, `Problem_code`) VALUES
(1, 'avatar', 'Kavinraj', '123', 'male', '1234098765', 'kavinraj@gmail.com', 'ISE', 'hosteller', 'SLB068', 'CLOUD COMPUTING - INFRASTRUCTURE SERVICES', 'IV', ' cl04'),
(3, 'universe', 'sudhar', '191cs298', 'male', '1234098765', 'sudhar@gmail.com', 'CSE', 'hosteller', 'SLB068', 'CLOUD COMPUTING - INFRASTRUCTURE SERVICES', 'IV', ' cl05');

-- --------------------------------------------------------

--
-- Table structure for table `team_attendance`
--

CREATE TABLE `team_attendance` (
  `team_name` varchar(255) NOT NULL,
  `lead_rollno` varchar(255) NOT NULL,
  `member_1_rollno` varchar(255) DEFAULT NULL,
  `member_2_rollno` varchar(255) DEFAULT NULL,
  `member_3_rollno` varchar(255) DEFAULT NULL,
  `member_4_rollno` varchar(255) DEFAULT NULL,
  `member_5_rollno` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team_marks`
--

CREATE TABLE `team_marks` (
  `id` int(11) NOT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `roll_no` varchar(20) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `team_marks`
--

INSERT INTO `team_marks` (`id`, `team_name`, `roll_no`, `marks`) VALUES
(1, 'Choose Team..', '191cs298', 95),
(2, '1', '191cs298', 90),
(3, 'Choose Team..', '191cs298', 90),
(4, 'Choose Team..', '191cs298', 90),
(5, 'Choose Team..', '191cs298', 90),
(6, 'Choose Team..', '191cs298', 90),
(7, 'Choose Team..', '191cs298', 90),
(8, '1', '191cs298', 90),
(9, '3', '191cs298', 95),
(10, '1', '192cb130', 92),
(11, 'Choose Team..', '122', 90);

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `member_id` int(11) NOT NULL,
  `team_id` int(11) DEFAULT NULL,
  `member_name` varchar(255) DEFAULT NULL,
  `member_roll` varchar(50) DEFAULT NULL,
  `member_gender` varchar(10) DEFAULT NULL,
  `member_phone` varchar(15) DEFAULT NULL,
  `member_mail` varchar(255) DEFAULT NULL,
  `member_department` varchar(255) DEFAULT NULL,
  `member_residence` varchar(50) DEFAULT NULL,
  `member_lab_id` varchar(50) DEFAULT NULL,
  `member_lab_name` varchar(255) DEFAULT NULL,
  `YEAR` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`member_id`, `team_id`, `member_name`, `member_roll`, `member_gender`, `member_phone`, `member_mail`, `member_department`, `member_residence`, `member_lab_id`, `member_lab_name`, `YEAR`) VALUES
(1, 1, 'naveenraj', '1234', 'male', '9363694140', 'naveen@gmail.com', 'IT', 'hosteller', 'SLB011', 'CYBER SECURITY', 'IV'),
(2, 1, 'Dhikshitha  S', '202234', 'female', '9363378160', 'DHIKSHITHA.CS22@BITSATHY.AC.IN', 'csbs', 'hosteller', 'SLB066', 'ARTIFICIAL INTELLIGENCE - INDUSTRIAL APPLICATIONS', 'IV'),
(3, 3, 'samantha', '1234', 'female', '98765432', 'samantha@gmail.com', 'CSBS', 'hosteller', 'SLB071', 'DATA SCIENCE - INDUSTRIAL APPLICATIONS', 'IV'),
(4, 3, 'sudharsan', '12222', 'male', '12234', 'SUDHARSAN.CD22@BITSATHY.AC.IN', 'IT', 'day_scholar', 'SLB023', 'ARTIFICIAL INTELLIGENCE - INDUSTRIAL APPLICATIONS', 'IV'),
(5, 3, 'NIKITHA M', '202IT175', 'female', '6380072121', 'NIKITHA.SE21@BITSATHY.AC.IN', 'AD', 'hosteller', 'SLB008', 'DATA SCIENCE - INDUSTRIAL APPLICATIONS', 'IV'),
(6, 3, 'JANARTHAN K', '7376221CS175', 'male', '6374337648', 'JANARTHAN.CS22@BITSATHY.AC.IN', 'IT', 'hosteller', 'SLB066', 'MOBILE AND WEB APP FOR SOFTWARE APPLICATIONS', 'IV');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`team_id`);

--
-- Indexes for table `team_attendance`
--
ALTER TABLE `team_attendance`
  ADD PRIMARY KEY (`team_name`);

--
-- Indexes for table `team_marks`
--
ALTER TABLE `team_marks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`member_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `team_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `team_marks`
--
ALTER TABLE `team_marks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `team_members`
--
ALTER TABLE `team_members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
