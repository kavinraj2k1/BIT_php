<?php
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {
    $database_name = $_SESSION['db_name']; 
$connection = mysqli_connect("localhost", "root", "", $database_name);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $team_id = $_POST["team_id"];

    // Loop through member fields
    for ($i = 1; isset($_POST["member_name_$i"]); $i++) {
        $member_name = $_POST["member_name_$i"];
        $member_roll = $_POST["member_roll_$i"];
        $member_year = $_POST["member_year_$i"];
        $member_gender = $_POST["member_gender_$i"];
        $member_phone = $_POST["member_phone_$i"];
        $member_mail = $_POST["member_mail_$i"];
        $member_department = $_POST["member_department_$i"];
        $member_residence = $_POST["member_residence_$i"];
        $member_lab_id = $_POST["member_lab_id_$i"];
        $member_lab_name = $_POST["member_lab_name_$i"];

        // Prepare the query template
        $query = "INSERT INTO team_members (team_id, member_name, member_roll, member_gender, member_phone, member_mail, member_department, member_residence, member_lab_id, member_lab_name,YEAR) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // Prepare the statement
        $stmt = mysqli_prepare($connection, $query);

        // Bind parameters
        mysqli_stmt_bind_param($stmt, "issssssssss", $team_id, $member_name, $member_roll, $member_gender, $member_phone, $member_mail, $member_department, $member_residence, $member_lab_id, $member_lab_name,$member_year);

        // Execute the statement
        $result = mysqli_stmt_execute($stmt);

        if (!$result) {
            echo "Error adding team members: " . mysqli_error($connection);
        }
    }

    mysqli_stmt_close($stmt);
    mysqli_close($connection);

    header("Location: ../user-dashboard/userindex.php");
    exit();
} else {
    echo "Invalid request.";
}
}
?>
