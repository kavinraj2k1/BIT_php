<!DOCTYPE html>
<html>
<head>
    <title>Add Team Members</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="styles.css">


    <!-- <script>
        $(document).ready(function() {
            var memberCount = 1;

            $("#add_member_button").click(function() {
                memberCount++;

                var newMemberField =
                    '<div class="member-details">' +
                    '<h3>Member ' + memberCount + '</h3>' +
                    '<label for="member_name_' + memberCount + '">Member Name:</label>' +
                    '<input type="text" name="member_name_' + memberCount + '" required><br>' +
                    '<label for="member_roll_' + memberCount + '">Member Roll Number:</label>' +
                    '<input type="text" name="member_roll_' + memberCount + '" required><br>' +
                    '<label for="member_mail_' + memberCount + '">Member Mail ID:</label>' +
                    '<input type="email" name="member_mail_' + memberCount + '" required><br>' +
                    '<label for="member_department_' + memberCount + '">Member Department:</label>' +
                    '<input type="text" name="member_department_' + memberCount + '" required><br>' +
                    '<label for="member_phone_' + memberCount + '">Member Phone Number:</label>' +
                    '<input type="text" name="member_phone_' + memberCount + '" required><br>' +
                    '<label for="member_gender_' + memberCount + '">Member Gender:</label>' +
                    '<input type="text" name="member_gender_' + memberCount + '" required><br>' +
                    '<label for="member_residence_' + memberCount + '">Member Hosteller/Day Scholar:</label>' +
                    '<input type="text" name="member_residence_' + memberCount + '" required><br>' +
                    '<label for="member_lab_id_' + memberCount + '">Member Lab ID:</label>' +
                    '<input type="text" name="member_lab_id_' + memberCount + '" required><br>' +
                    '<label for="member_lab_name_' + memberCount + '">Member Lab Name:</label>' +
                    '<input type="text" name="member_lab_name_' + memberCount + '" required><br>' +
                    '</div>';

                $("#member_fields").append(newMemberField);
            });
        });
    </script> --><script>
    $(document).ready(function() {
        var memberCount = 1;

        $("#add_member_button").click(function() {
            memberCount++;

            var newMemberField =
                '<div class="member-details">' +
                '<h3>Member ' + memberCount + '</h3>' +
                '<label for="member_name_' + memberCount + '">Member Name:</label>' +
                '<input type="text" name="member_name_' + memberCount + '" required><br>' +
                '<label for="member_roll_' + memberCount + '">Member Roll Number:</label>' +
                '<input type="text" name="member_roll_' + memberCount + '" required><br>' +
                '<label for="member_mail_' + memberCount + '">Member Mail ID:</label>' +
                '<input type="email" name="member_mail_' + memberCount + '" required><br>' +
                '<label for="member_department_' + memberCount + '">Member Department:</label>' +
                '<input type="text" name="member_department_' + memberCount + '" required><br>' +
                '<label for="member_phone_' + memberCount + '">Member Phone Number:</label>' +
                '<input type="text" name="member_phone_' + memberCount + '" required><br>' +
                '<label for="member_year_' + memberCount + '">Member year:</label>' +
                '<select name="member_year_' + memberCount + '" required>' +
                '<option>Choose Year..</option>'+
                '<option value="I">I</option>' +
                '<option value="II">II</option>' +
                '<option value="III">III</option>' +
                '<option value="IV">IV</option>' +
                '</select><br>' +
                '<label for="member_gender_' + memberCount + '">Member Gender:</label>' +
                '<select name="member_gender_' + memberCount + '" required>' +
                '<option>Choose Gender..</option>'+
                '<option value="male">Male</option>' +
                '<option value="female">Female</option>' +
                '<option value="other">Other</option>' +
                '</select><br>' +
                '<label for="member_residence_' + memberCount + '">Member Hosteller/Day Scholar:</label>' +
                '<select name="member_residence_' + memberCount + '" required>' +
                '<option>Choose Residence..</option>'+
                '<option value="hosteller">Hosteller</option>' +
                '<option value="day_scholar">Day Scholar</option>' +
                '</select><br>' +
                '<label for="member_lab_id_' + memberCount + '">Member Lab ID:</label>' +
                '<input type="text" name="member_lab_id_' + memberCount + '" required><br>' +
                '<label for="member_lab_name_' + memberCount + '">Member Lab Name:</label>' +
                '<input type="text" name="member_lab_name_' + memberCount + '" required><br>' +
                '</div>';

            $("#member_fields").append(newMemberField);
        });
    });
</script>

</head>
<body>
    <h1>Add Team Members</h1>
    <form action="process_members.php" method="post">
        <input type="hidden" name="team_id" value="<?php echo $_GET['team_id']; ?>">
        
        <div id="member_fields">
            <!-- Initial member details fields -->
            <!-- ... Previous HTML code ... -->

<div class="member-details">
    <h3>Member 1</h3>
    <label for="member_name_1">Member Name:</label>
    <input type="text" name="member_name_1" required><br>
    <label for="member_roll_1">Member Roll Number:</label>
    <input type="text" name="member_roll_1" required><br>
    <label for="member_mail_1">Member Mail ID:</label>
    <input type="email" name="member_mail_1" required><br>
    <label for="member_department_1">Member Department:</label>
    <input type="text" name="member_department_1" required><br>
    <label for="member_phone_1">Member Phone Number:</label>
    <input type="text" name="member_phone_1" required><br>
    <label for="member_year_1">Member Gender:</label>
    <select name="member_year_1" required>
        <option>Choose Year..</option>
        <option value="I">I</option>
        <option value="II">II</option>
        <option value="III">III</option>
        <option value="IV">IV</option>
    </select><br>
    <label for="member_gender_1">Member Gender:</label>
    <select name="member_gender_1" required>
        <option>Choose Gender..</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
        <option value="other">Other</option>
    </select><br>
    <label for="member_residence_1">Member Hosteller/Day Scholar:</label>
    <select name="member_residence_1" required>
        <option>Choose Residence..</option>
        <option value="hosteller">Hosteller</option>
        <option value="day_scholar">Day Scholar</option>
    </select><br>
    <label for="member_lab_id_1">Member Lab ID:</label>
    <input type="text" name="member_lab_id_1" required><br>
    <label for="member_lab_name_1">Member Lab Name:</label>
    <input type="text" name="member_lab_name_1" required><br>
</div>

<!-- ... Rest of the HTML ... -->

        </div>
        
        <button type="button" id="add_member_button">Add Member</button>
        <input type="submit" value="Submit">
    </form>
</body>
</html>
