<?php 
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {
     $database_name = $_SESSION['db_name']; 
$connection = mysqli_connect("localhost", "root", "", $database_name);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT team_id, team_name FROM teams";
$result = mysqli_query($connection, $query);

$teams = array();
while ($row = mysqli_fetch_assoc($result)) {
    $teams[$row['team_id']] = $row['team_name'];
}

mysqli_close($connection);
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard | <?php echo $_SESSION['event_org']; ?> <?php echo $_SESSION['event_type']; ?></title>
</head>
<body>
    <h1>Select a Team</h1>
    <form action="selected_team.php" method="post">
        <label for="team_selection">Select a Team:</label>
        <select name="team_id" id="team_selection">
        <option>Choose Team..</option>
            <?php foreach ($teams as $team_id => $team_name) { ?>
                <option value="<?php echo $team_id; ?>"><?php echo $team_name; ?></option>
            <?php } ?>
        </select>
        <br>
        <input type="submit" value="Select">
    </form>
</body>
</html>
