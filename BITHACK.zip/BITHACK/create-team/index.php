<?php 
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {
   
    ?>
    <!DOCTYPE html>
    
    <html>
<head>
<title>Dashboard | <?php echo $_SESSION['event_org']; ?> <?php echo $_SESSION['event_type']; ?></title>
    <link rel="stylesheet" type="text/css" href="styles.css">

  
</head>
<body>
    <h1>Create Team</h1>
   
    <form action="create_team.php" method="post"><a href="../user-dashboard/userindex.php"><input type="button" value="Back"></a><br><br>
        <label for="team_name">Team Name:</label>
        <input type="text" name="team_name" required><br>
        
        <label for="team_lead_name">Team Lead Name:</label>
        <input type="text" name="team_lead_name" required><br>
        
        <label for="team_lead_roll">Team Lead Roll Number:</label>
        <input type="text" name="team_lead_roll" required><br>
        
        <label for="team_lead_mail">Team Lead Mail ID:</label>
        <input type="email" name="team_lead_mail" required><br>
        
        <label for="team_lead_department">Team Lead Department:</label>
        <input type="text" name="team_lead_department" required><br>

        <label for="team_lead_gender">Team Lead Year:</label>
        <select name="team_lead_year" required>
            <option>Choose Year..</option>
            <option value="I">I</option>
            <option value="II">II</option>
            <option value="III">III</option>
            <option value="IV">IV</option>
        </select><br>
        
        <label for="team_lead_phone">Team Lead Phone Number:</label>
        <input type="text" name="team_lead_phone" required><br>
        
        <label for="team_lead_gender">Team Lead Gender:</label>
        <select name="team_lead_gender" required>
            <option>Choose Gender..</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
        </select><br>
        
        <label for="team_lead_residence">Team Lead Hosteller/Day Scholar:</label>
        <select name="team_lead_residence" required>
            <option>Choose Residence..</option>
            <option value="hosteller">Hosteller</option>
            <option value="day_scholar">Day Scholar</option>
        </select><br>
        
        <label for="lab_id">Lab ID:</label>
        <input type="text" name="lab_id" required><br>
        <!-- <select id="stateSelect">
                                    <option>Choose Lab Id..</option>
                                    <option value="SLB082">SLB082</option>
                                    <option value="SLB008">SLB008</option>
                                    <option value="SLB068">SLB068</option>
                                    <option value="SLB002">SLB002</option>
                                </select> -->
                            
        
        <label for="lab_name">Lab Name:</label>
        <input type="text" name="lab_name" required><br>
        <!-- <select id="districtSelect">
                                    <option>Choose District..</option>
                                </select> -->
        
        <label for="problem_code">Problem Code:</label>
        <select name="problem_code" required>
            <option>Choose Problem code..</option>
            <option value="cl01">CL01</option>
            <option value="cl02">CL02</option>
            <option value="cl03">CL03</option>
            <option value="cl04">CL04</option>
            <option value="cl05">CL05</option>
           

        </select><br><br>

        <input type="submit" value="Create Team">
        
    </form>

  



    <script> // Get references to the select elements
const stateSelect = document.getElementById("stateSelect");
const districtSelect = document.getElementById("districtSelect");

// District data for each state
const districtData = {
    SLB082: ["CLOUD COMPUTING - SOFTWARE SERVICES"],
    SLB008: ["CLOUD COMPUTING - INFRASTRUCTURE SERVICES"],
    SLB068: ["DATA SCIENCE - COMPUTATIONAL INTELLIGENCE"],
    SLB002: ["DATA SCIENCE - INDUSTRIAL APPLICATIONS"]
};

// Function to populate districts based on selected state
function populateDistricts() {
    const selectedLabID = stateSelect.value;
    const labNames = districtData[selectedLabID] || [];

    // Clear existing options
    districtSelect.innerHTML = ""; // Clear existing options before adding new ones

    // Populate lab name options
    labNames.forEach(labName => {
        const option = document.createElement("option");
        option.value = labName;
        option.textContent = labName;
        districtSelect.appendChild(option);
    });
}

// Event listener for lab ID select change
stateSelect.addEventListener("change", populateDistricts);

// Initial population of lab names
populateDistricts();
</script>
</body>
</html>
<?php 
}else{
     header("Location: ../login-session/index.php");
     exit();
}
 ?>