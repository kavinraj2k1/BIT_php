<?php
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation']) && isset($_SESSION['domain']) && isset($_SESSION['user_name']) && isset($_SESSION['role']) && isset($_SESSION['db_name'])) {
    $database_name = $_SESSION['db_name']; 
$connection = mysqli_connect("localhost", "root", "", $database_name);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $team_name = $_POST["team_name"];
    $team_lead_name = $_POST["team_lead_name"];
    $team_lead_roll = $_POST["team_lead_roll"];
    $team_lead_year = $_POST["team_lead_year"];
    $team_lead_gender = $_POST["team_lead_gender"];
    $team_lead_phone = $_POST["team_lead_phone"];
    $team_lead_mail = $_POST["team_lead_mail"];
    $team_lead_department = $_POST["team_lead_department"];
    $team_lead_residence = $_POST["team_lead_residence"];
    $lab_id = $_POST["lab_id"];
    $lab_name = $_POST["lab_name"];
    $problem_code = $_POST["problem_code"];
    
    $query = "INSERT INTO teams (team_name, team_lead_name, team_lead_roll, team_lead_gender, team_lead_phone, team_lead_mail, team_lead_department, team_lead_residence, lab_id, lab_name,YEAR,problem_code) VALUES ('$team_name', '$team_lead_name', '$team_lead_roll', '$team_lead_gender', '$team_lead_phone', '$team_lead_mail', '$team_lead_department', '$team_lead_residence', '$lab_id', '$lab_name','$team_lead_year',' $problem_code')";
    $result = mysqli_query($connection, $query);

    if ($result) {
        $team_id = mysqli_insert_id($connection);
        header("Location: add_members.php?team_id=$team_id");
        exit();
    } else {
        echo "Error creating team: " . mysqli_error($connection);
    }
}

mysqli_close($connection);
}
?>
