document.addEventListener('DOMContentLoaded', function() {
    var nextButton = document.getElementById('nextButton');
    var loading = document.querySelector('.loading');

    nextButton.addEventListener('click', function() {
        loading.style.display = 'flex';

        setTimeout(function() {
            window.location.href = 'user-dashboard/userindex.php';
        }, 2000); // 2 seconds delay
    });
});
