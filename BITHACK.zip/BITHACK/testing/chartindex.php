<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="chartstyle.css">
    <title>Attendance Graph</title>
</head>
<body>
    <div id="attendanceChart"></div>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <script src="chartscript.js"></script>
</body>
</html>
