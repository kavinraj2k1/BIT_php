<?php

$databases = [
    [
        'servername' => "localhost",
        'username' => "root",
        'password' => "",
        'dbname' => "scloud" // Replace with your first database name
    ],
    [
        'servername' => "localhost",
        'username' => "root",
        'password' => "",
        'dbname' => "sweb" // Replace with your second database name
    ]
];