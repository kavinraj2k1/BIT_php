<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // $to = $_POST["email"];
    $reset_code = rand(1000, 9999);  // Generate a random 4-digit code

    // // Send reset code to email
    // // Example using mail() function (configure your email server first)
    // $subject = "Password Reset Code";
    // $message = "Your password reset code is: $reset_code";

    $to = $_POST["email"];
    $subject = "Password Reset Code";
    $message = "Your password reset code is: $reset_code";

    // Additional headers (optional)
    $headers = "From: sender123@example.com\r\n";
    $headers .= "Reply-To: sender123@example.com\r\n";

   $mailSuccess = mail($to, $subject, $message, $headers);

if ($mailSuccess) {
    echo "Email sent successfully.";
} else {
    echo "Failed to send email.";
}
}
?>
