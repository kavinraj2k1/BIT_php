<?php
// Define an array of databases with their credentials
$databases = [
    [
        'servername' => "localhost",
        'username' => "root",
        'password' => "",
        'dbname' => "scloud" // Replace with your first database name
    ],
    [
        'servername' => "localhost",
        'username' => "root",
        'password' => "",
        'dbname' => "sweb" // Replace with your second database name
    ]
];

// Initialize a variable to keep track of the total count
$totalCounts = [
    'I' => 0,
    'II' => 0,
    'III' => 0,
    'IV' => 0
];

foreach ($databases as $db) {
    try {
        $conn = new PDO("mysql:host={$db['servername']};dbname={$db['dbname']}", $db['username'], $db['password']);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Query the database to get the counts for each year
        $years = ['I', 'II', 'III', 'IV'];

        foreach ($years as $year) {
            try {
                // Query for teams count
                $stmt_teams = $conn->prepare("
                    SELECT
                        COUNT(*) AS team_count
                    FROM
                        teams
                    WHERE
                        YEAR = :year
                ");
                $stmt_teams->bindParam(':year', $year);
                $stmt_teams->execute();

                // Query for team_members count
                $stmt_members = $conn->prepare("
                    SELECT
                        COUNT(*) AS member_count
                    FROM
                        team_members
                    WHERE
                        YEAR = :year
                ");
                $stmt_members->bindParam(':year', $year);
                $stmt_members->execute();

                $result_teams = $stmt_teams->fetch(PDO::FETCH_ASSOC);
                $result_members = $stmt_members->fetch(PDO::FETCH_ASSOC);

                // Calculate the total count for this year
                $yearlyCount = ($result_teams ? $result_teams['team_count'] : 0) + ($result_members ? $result_members['member_count'] : 0);

                // Update the total count for this year
                $totalCounts[$year] += $yearlyCount;

            } catch (PDOException $e) {
                // Handle database error
                echo '<div class="user">
                        <h2>' . $year . ' YEAR</h2>
                        <p>Database Error</p>
                    </div>';
            }
        }

        // Close the database connection
        $conn = null;

    } catch (PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        die();
    }
}

// Display the combined results
foreach ($totalCounts as $year => $count) {
    echo '<div class="user">
            <h2>' . $year . ' YEAR</h2>
            <p>' . $count . '</p>
          </div>';

          
}
$overallCount = array_sum($totalCounts);
echo '<div class="user">
        <h2>OVERALL</h2>
        <p>' . $overallCount . '</p>
      </div>';

?>
