<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $reset_code = $_POST["reset_code"];
    $new_password = $_POST["new_password"];

    // Verify reset code (you might want to store reset codes in a database)
    // If the reset code is valid, update the password for the associated email

    // For simplicity, let's assume the email and reset code are correct
    // In a real-world application, validate the code against a stored value
    $success_message = "Password changed successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Changed</title>
</head>
<body>
    <?php if (isset($success_message)) {
        echo "<p>$success_message</p>";
    } ?>
</body>
</html>
