document.addEventListener('DOMContentLoaded', function () {
    // Fetch data from the server
    fetch('chartgetData.php')
        .then(response => response.json())
        .then(data => {
            // Process data and create the chart
            createAttendanceChart(data);
        })
        .catch(error => console.error('Error fetching data:', error));
});

function createAttendanceChart(data) {
    // Assuming your PHP script returns 'overall_attendance_percentage' in the JSON
    const overallAttendancePercentage = data.overall_attendance_percentage;

    // Creating a simple text display for overall attendance percentage
    const textDisplay = document.createElement('div');
    textDisplay.innerHTML = `<h2>Overall Attendance Percentage: ${overallAttendancePercentage}%</h2>`;
    document.body.appendChild(textDisplay);
}
