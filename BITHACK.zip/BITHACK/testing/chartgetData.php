<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "scloud";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch overall attendance percentage from start date to today's date
$sql = "SELECT COUNT(*) as total_records, AVG(IF(attendance_date <= CURDATE(), 1, 0)) as overall_attendance_percentage 
        FROM attendance";
$result = $conn->query($sql);

$data = array();

if ($row = $result->fetch_assoc()) {
    $totalRecords = $row['total_records'];
    $overallAttendancePercentage = round($row['overall_attendance_percentage'] * 100, 2); // Convert to percentage

    // Assuming you want to calculate the attendance percentage based on the total number of records
    if ($totalRecords > 0) {
        $data['overall_attendance_percentage'] = $overallAttendancePercentage;
    } else {
        $data['overall_attendance_percentage'] = 0;
    }
}

// Close connection
$conn->close();

// Return data as JSON
header('Content-Type: application/json');
echo json_encode($data);
?>
