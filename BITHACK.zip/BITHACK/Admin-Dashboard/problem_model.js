document.addEventListener('DOMContentLoaded', () => {
    const problemModal = document.getElementById('problem-modal');
    const openProblemModalBtn = document.getElementById('open-problem-modal-btn');
    const closeProblemModalBtn = document.querySelector('.close-problem');

    openProblemModalBtn.addEventListener('click', () => {
        problemModal.style.display = 'block';
    });

    closeProblemModalBtn.addEventListener('click', () => {
        problemModal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target == problemModal) {
            problemModal.style.display = 'none';
        }
    });
});



document.addEventListener('DOMContentLoaded', () => {
    const textElement = document.getElementById('open-problem-modal-btn');

    anime({
        targets: textElement,
        loop: true,
        easing: 'easeInOutQuad',
        opacity: [0.5, 1],
        scale: [1, 1.05],
        direction: 'alternate',
        duration: 500
    });
});