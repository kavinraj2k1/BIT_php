<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $eventName = $conn->real_escape_string($_POST["event-name"]);
    $eventType = $conn->real_escape_string($_POST["event-type"]);
    $eventDate = $conn->real_escape_string($_POST["event-date"]);
    $eventStatus = $conn->real_escape_string($_POST["event-status"]);

    $sql = "INSERT INTO events (event_name, event_type, date, status)
        VALUES ('$eventName', '$eventType', '$eventDate', '$eventStatus')";


    if ($conn->query($sql) === TRUE) {
        header("Location: index.php?success=1");
            exit();
        // echo "Event added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
