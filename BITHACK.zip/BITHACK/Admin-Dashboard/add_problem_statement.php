<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$problem_code = $_POST['problem_code'];
$problem_statement = $_POST['problem_statement'];
$domain = $_POST['domain'];

$sql = "INSERT INTO problem_statement (problem_code, problem_statement, domain) VALUES ('$problem_code', '$problem_statement', '$domain')";

if ($conn->query($sql) === TRUE) {
    header("Location: problemstatement.php?success=1");
            exit();
    // echo "Problem statement added successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
