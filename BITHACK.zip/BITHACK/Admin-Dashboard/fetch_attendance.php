<?php

// Define an array of databases with their credentials
$databases = [
    [
        'servername' => "localhost",
        'username' => "root",
        'password' => "",
        'dbname' => "scloud" // Replace with your first database name
    ],
    [
        'servername' => "localhost",
        'username' => "root",
        'password' => "",
        'dbname' => "scyber" // Replace with your first database name
    ],
    [
        'servername' => "localhost",
        'username' => "root",
        'password' => "",
        'dbname' => "sweb" // Replace with your second database name
    ]
];

// Define the date range you want to retrieve attendance for
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

// Initialize a variable to keep track of the total count
$totalCount = 0;

// Initialize an array to store individual database counts
$databaseCounts = [];

foreach ($databases as $db) {
    try {
        $conn = new PDO("mysql:host={$db['servername']};dbname={$db['dbname']}", $db['username'], $db['password']);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        try {
            // Query for student attendance details within the date range
            $stmt_attendance = $conn->prepare("
                SELECT COUNT(*) AS attendance_count
                FROM attendance
                WHERE attendance_date BETWEEN :start_date AND :end_date
            ");
            $stmt_attendance->bindParam(':start_date', $start_date);
            $stmt_attendance->bindParam(':end_date', $end_date);
            $stmt_attendance->execute();

            $result_attendance = $stmt_attendance->fetch(PDO::FETCH_ASSOC);

            // Update the total count
            $count = $result_attendance ? $result_attendance['attendance_count'] : 0;
            $totalCount += $count;

            // Store individual database count
            $databaseCounts[$db['dbname']] = $count;

        } catch (PDOException $e) {
            // Handle database error
            echo '<div class="user">
                    <p>Database Error</p>
                </div>';
        }

        // Close the database connection
        $conn = null;

    } catch (PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        die();
    }
}

    // Display the total count
    // header("Location: reports.php?error=<h2>Attendance Details</h2> <p>Total Attendance:  . $totalCount . ");
    // exit();
    // echo '<div class="user">
    //         <h2>Attendance Details</h2>
    //         <p>Total Attendance: ' . $totalCount . '</p>
    //     </div>';

// Display individual database counts
echo '<div class="user">
        <h1>Attendance Details</h1>
        <h2>Total Attendance: ' . $totalCount . '</h2>';
foreach ($databaseCounts as $dbName => $count) {
    echo "<h2>{$dbName} Attendance: {$count}</h2>";
}
// echo '</div>';
echo '<h3><a href="reports.php?">Go to Reports</a></h3></div>';

?>
