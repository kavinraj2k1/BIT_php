
document.addEventListener('DOMContentLoaded', () => {
    const tbody = document.getElementById('user-table');

    fetch('fetch_users.php')
        .then(response => response.json())
        .then(data => {
            data.forEach(user => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${user.name}</td>
                    <td>${user.staff_id}</td>
                    <td>${user.designation}</td>
                    <td>${user.domain}</td>
                    <td></td>
                `;
                tbody.appendChild(tr);
            });
        });
});