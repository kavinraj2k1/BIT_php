document.addEventListener('DOMContentLoaded', () => {
    const tbody = document.getElementById('statement-table');

    fetch('fetch_statement.php')
        .then(response => response.json())
        .then(data => {
            data.forEach(problem => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${problem.problem_code}</td>
                    <td>${problem.problem_statement}</td>
                    <td>${problem.domain}</td>
                `;
                tbody.appendChild(tr);
            });
        });
});
