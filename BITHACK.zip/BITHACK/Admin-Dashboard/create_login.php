<?php
// Assuming you have already established a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$staff_id = $_POST['staff_id'];
$designation = $_POST['designation'];
$domain = $_POST['domain'];
$role = $_POST['role'];
$username = $_POST['username'];
$password = $_POST['password'];

// Escape special characters to prevent SQL injection
$name = mysqli_real_escape_string($conn, $name);
$staff_id = mysqli_real_escape_string($conn, $staff_id);
$designation = mysqli_real_escape_string($conn, $designation);
$domain = mysqli_real_escape_string($conn, $domain);
$role = mysqli_real_escape_string($conn, $role);
$username = mysqli_real_escape_string($conn, $username);

// Hash the password
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

// Create SQL query
$sql = "INSERT INTO admin_table (name, staff_id, designation, domain, role, user_name, password)
        VALUES ('$name', '$staff_id', '$designation', '$domain', '$role', '$username', '$passwordHash')";

if ($conn->query($sql) === TRUE) {
  header("Location: new_login.php?success=1");
  exit();
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
