<?php 
session_start();

if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation'])&& isset($_SESSION['domain'])&& isset($_SESSION['user_name'])&& isset($_SESSION['role'])) {

 ?>
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Dashboard | <?php echo $_SESSION['event_org']; ?> <?php echo $_SESSION['event_type']; ?></title>
</head>

<body>

    <div class="container">
        <!-- Sidebar Section -->
        <aside>
            <div class="toggle">
                <div class="logo">
                    <img src="images/logo1.png">
                    <h2><?php echo $_SESSION['event_org']; ?><span class="danger"><?php echo $_SESSION['event_type']; ?> </span></h2>
                </div>
                <div class="close" id="close-btn">
                    <span class="material-icons-sharp">close</span>
                </div>
            </div>

            <div class="sidebar">
                <a href="dashboard.php">
                    <span class="material-icons-sharp">dashboard</span>
                    <h3>Dashboard</h3>
                </a>
                <a href="users.php" >
                    <span class="material-icons-sharp">person_outline</span>
                    <h3>Users</h3>
                </a>
                <a href="problemstatement.php">
                    <span class="material-icons-sharp">receipt_long</span>
                    <h3>Problem Statement</h3>
                </a>
                <a href="index.php" >
                    <span class="material-icons-sharp">insights</span>
                    <h3>Analytics</h3>
                </a>
                <a href="individual_teams.php">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Teams</h3>
                </a>
                <!-- <a href="#">
                    <span class="material-icons-sharp"> mail_outline</span>
                    <h3>Tickets</h3>
                    <span class="message-count">27</span>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Sale List</h3>
                </a> -->
                <a href="reports.php">
                    <span class="material-icons-sharp">report_gmailerrorred</span>
                    <h3>Reports</h3>
                </a>
                <a href="profile.php" class="active">
                    <span class="material-icons-sharp"> settings</span>
                    <h3>Settings</h3>
                </a>
                <a href="new_login.php">
                    <span class="material-icons-sharp">add</span>
                    <h3>New Login</h3>
                </a>
                <a href="create_db.php">
                    <span class="material-icons-sharp">add</span>
                    <h3 id="open-modal-btn1">Create DB</h3>
                </a>
                <a href="../login-session/logout.php">
                    <span class="material-icons-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <!-- End of Sidebar Section -->

        <!-- Main Content -->
        <main>
           
            <!-- End of Analyses -->

            <div class="new-users">
                <h2>Profile</h2>
                <div class="user-list">
                    <div class="user">
                        <!-- <form >
                            <label > Team name</label>
                            <input type="text"><br>
                            <label >Enter Mark</label>
                            <input type="text"><br>
                            
                        </form><form action="selected_team.php" method="post"> -->
                      
        <!-- <label >Team Name</label>
                            <input type="text" name="teamName" id="team_name" placeholder="Team Name" required> -->
                            <?php
// Check if the success parameter is set
if (isset($_GET['success']) && $_GET['success'] == '1') {
    echo '<div style="color: green;"><h2>Password Updated successfully!</h2></div>';
}
?>
                            <label >Name</label>
                            <input type="text" name="leadRole" id="roll_no" placeholder="<?php echo $_SESSION['name']; ?>" readonly>
                            <label >Staff Id</label>
                            <input type="text" name="marks" id="marks" placeholder="<?php echo $_SESSION['staff_id']; ?>" readonly><br>
                            <label >Designation</label>
                            <input type="text" name="marks" id="marks" placeholder="<?php echo $_SESSION['designation']; ?>" readonly><br>
                            <label >Domain</label>
                            <input type="text" name="marks" id="marks" placeholder="<?php echo $_SESSION['domain']; ?>" readonly><br>
                            <label >Role</label>
                            <input type="text" name="marks" id="marks" placeholder="<?php echo $_SESSION['role']; ?>" readonly><br>
                            <a href="../login-session/change_password.php"> <p>Click Here to change password for admin</p></a>
        
                </div>
            </div>
            <!-- New Users Section -->
            

        </main>
        <!-- End of Main Content -->
        <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    die();
}

// Initialize variables to store the last notification and its date and time
$lastNotification = "";
$lastDateTime = "";

// Query to fetch the last notification and its date and time from the database
try {
    $stmt_last_notification = $conn->prepare("
        SELECT
            notification,
            date_time
        FROM
            admin_notify
        ORDER BY
            id DESC
        LIMIT 1
    ");
    $stmt_last_notification->execute();

    // Fetch the last notification and its date and time
    $lastNotificationRow = $stmt_last_notification->fetch(PDO::FETCH_ASSOC);
    
    if ($lastNotificationRow) {
        $lastNotification = $lastNotificationRow['notification'];
        $lastDateTime = $lastNotificationRow['date_time'];
    }
} catch (PDOException $e) {
    // Handle database error for fetching the last notification
    echo '<p class="notification">Error fetching the last notification</p>';
}

// Close the database connection
$conn = null;

// Display the last notification and its date and time
// echo '<div class="last-notification">';
// if (!empty($lastNotification)) {
//     echo '<p class="notification">' . $lastNotification . '</p>';
//     echo '<p class="datetime">Date and Time: ' . $lastDateTime . '</p>';
// } else {
//     echo '<p class="notification">No notifications found</p>';
// }
// echo '</div>';
?>
        <!-- Right Section -->
        <div class="right-section">
            <div class="nav">
                <button id="menu-btn">
                    <span class="material-icons-sharp">menu</span>
                </button>
                <div class="dark-mode">
                    <span class="material-icons-sharp active">light_mode</span>
                    <span class="material-icons-sharp">dark_mode</span>
                </div>

                <div class="profile">
                    <div class="info">
                        <p>Hey, <b><?php echo $_SESSION['name']; ?></b></p>
                        <small class="text-muted"><?php echo $_SESSION['role']; ?></small>
                    </div>
                    <div class="profile-photo">
                        <img src="images/profile-1.jpg">
                    </div>
                </div>

            </div>
            <!-- End of Nav -->

            <div class="user-profile">
                <div class="logo">
                    <img src="images/logo1.png">
                    <h2><?php echo $_SESSION['event_org']; ?> <?php echo $_SESSION['event_type']; ?></h2>
                    <p><?php echo $_SESSION['organizer']; ?></p>
                </div>
            </div>

            <div class="reminders">
                <div class="header">
                    <h2>Reminders</h2>
                    <span class="material-icons-sharp">notifications_none</span>
                </div>
                <div class="notification" >
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                        
                    </div>
                    <div class="content" id="blink">
                        <div class="info" >
                            <h3><?php echo ' ' . $lastNotification . '';?></h3>
                            <small class="text_muted"><?php echo ' ' . $lastDateTime . '';?> </small>
                            
                        </div>
                    </div>
                </div>
                <!-- <marquee behavior="scroll" direction="up" scrollamount="5">
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div>
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div>
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div>
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div>
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div>
                <div class="notification deactive">
                    <div class="icon">
                        <span class="material-icons-sharp">edit</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM </small>
                        </div>
                        <span class="material-icons-sharp"> more_vert</span>
                    </div>
                </div></marquee> -->

                <div class="notification add-reminder">
                    <div>
                    <span class="material-icons-sharp">add</span>
                        <h3 id="open-modal-btn">Add Reminder</h3>
                        <!-- <button id="open-modal-btn">Open Modal</button> -->
                        <!-- <button id="open-modal-btn" >Add Reminder</button> -->
                    </div>
                </div>
                
                <!-- <button id="open-modal-btn" >Add Reminder</button> -->
                    <div id="modal" class="modal">
                    <div class="modal-content">
                        <span class="close1">&times;</span>
                        <h2>Notification</h2>
                        <form action="notify.php" method="post">
                        <textarea id="message" name="notify" required></textarea>
                        <label for="datetime">Date and Time:</label>
                        <input type="datetime-local" id="datetime" name="datetime" required>
                        <button type="submit" id="submit-modal-btn">Submit</button>
                        </form>
                    </div>
                    </div>
            </div>

        </div>
            </div>

        </div>


    </div>
    <script src="blink.js"></script>
    <script src="orders.js"></script>
    <script src="index.js"></script>
    <script src="model.js"></script>
</body>

</html>
<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>























