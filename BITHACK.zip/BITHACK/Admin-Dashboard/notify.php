<?php
$connection = mysqli_connect("localhost", "root", "", "admin");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $test_message = $_POST["notify"];
    $date_time = $_POST["datetime"]; // This will contain the date and time from the form.

    $query = "INSERT INTO admin_notify (notification, date_time) VALUES ('$test_message', '$date_time')";
    $result = mysqli_query($connection, $query);

    if ($result) {
        $notify_id = mysqli_insert_id($connection);
        // Redirect the user to the next page after successful submission
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($connection);
    }
}

mysqli_close($connection);
?>
