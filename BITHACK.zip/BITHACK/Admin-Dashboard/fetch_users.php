<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT * FROM admin_table ORDER BY id ASC";
$result = $conn->query($sql);

// Convert data to JSON and send it to JavaScript
$data = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

$conn->close();

// Send data as JSON
header('Content-Type: application/json');
echo json_encode($data);
?>
