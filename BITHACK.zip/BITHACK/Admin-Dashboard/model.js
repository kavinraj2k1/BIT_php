document.addEventListener("DOMContentLoaded", function() {
    const openModalButton = document.getElementById("open-modal-btn");
    const closeModalButton = document.querySelector(".close1");
    const modal = document.getElementById("modal");
    const messageForm = document.getElementById("message-form");
  
    openModalButton.addEventListener("click", function() {
      modal.style.display = "block";
    });
  
    closeModalButton.addEventListener("click", function() {
      modal.style.display = "none";
    });
  
    messageForm.addEventListener("submit", function(event) {
      event.preventDefault(); // Prevent the default form submission
      const message = document.getElementById("message").value;
      alert(`Submitted message:`);
      modal.style.display = "none";
    });
});


