// const Orders = [
//     {
//         eventname: 'BIT HACK23',
//         eventtype: 'HACKATHON',
//         date: 'SEP 02',
//         status: 'Approved'
//     },
//     {
//         productName: 'CSS Full Course',
//         productNumber: '97245',
//         paymentStatus: 'Refunded',
//         status: 'Declined'
//     },
//     {
//         productName: 'Flex-Box Tutorial',
//         productNumber: '36452',
//         paymentStatus: 'Paid',
//         status: 'Active'
//     },
//     {
//         eventname: 'Product Expo',
//         eventtype: 'Expo',
//         date: 'SEP 20',
//         status: 'Pending'
//     },
// ]





    document.addEventListener('DOMContentLoaded', () => {
        const tbody = document.getElementById('orders-table');

        fetch('backend.php')
            .then(response => response.json())
            .then(data => {
                data.forEach(order => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${order.event_name}</td>
                        <td>${order.event_type}</td>
                        <td>${order.date}</td>
                        <td>${order.status}</td>
                        <td></td>
                    `;
                    tbody.appendChild(tr);
                });
            });
    });

