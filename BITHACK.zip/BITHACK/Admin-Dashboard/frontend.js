document.addEventListener("DOMContentLoaded", function() {
    const openEventModalButton = document.getElementById("open-event-modal-btn");
    const closeEventModalButton = document.querySelector(".close2");
    const eventModal = document.getElementById("event-modal");
    const eventForm = document.getElementById("event-form");

    openEventModalButton.addEventListener("click", function() {
        eventModal.style.display = "block";
    });

    closeEventModalButton.addEventListener("click", function() {
        eventModal.style.display = "none";
    });

    eventForm.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the default form submission
        const eventName = document.getElementById("event-name").value;
        const eventType = document.getElementById("event-type").value;
        const eventDate = document.getElementById("event-date").value;
        const eventStatus = document.getElementById("event-status").value;

        alert(`Submitted Event Details:\nName: ${eventName}\nType: ${eventType}\nDate: ${eventDate}\nStatus: ${eventStatus}`);

        eventModal.style.display = "none";
    });
});
