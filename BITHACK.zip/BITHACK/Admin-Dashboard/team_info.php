<?php 
session_start();

if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation'])&& isset($_SESSION['domain'])&& isset($_SESSION['user_name'])&& isset($_SESSION['role'])) {

 ?>
 <?php
require_once('database_connection.php');

// Query for attendance percentages
$attendance_query = "
SELECT t.team_name, 
       AVG(CASE WHEN a.attendance_date = CURDATE() THEN 1 ELSE 0 END) * 100 as attendance_percentage
FROM teams t
JOIN attendance a ON t.team_id = a.team_name
GROUP BY t.team_name;
";


$attendance_result = $conn->query($attendance_query);

// Query for marks percentages
$marks_query = "
SELECT t.team_name, AVG(m.marks) as marks_percentage
FROM teams t
JOIN team_marks m ON t.team_id = m.team_name
GROUP BY t.team_name;
";

$marks_result = $conn->query($marks_query);

// Combine the results
$team_data = array();

while ($row = $attendance_result->fetch_assoc()) {
    $team_data[$row['team_name']]['attendance_percentage'] = $row['attendance_percentage'];
}

while ($row = $marks_result->fetch_assoc()) {
    $team_data[$row['team_name']]['marks_percentage'] = $row['marks_percentage'];
}

?>

<!DOCTYPE html>
<html>
<head>
<!-- <link rel="stylesheet" href="style.css"> -->
<title>Dashboard | <?php echo $_SESSION['event_org']; ?> <?php echo $_SESSION['event_type']; ?></title>
    <style>
        /* Table Header Styles */
th {
    background-color: #f2f2f2;
    font-weight: bold;
}

/* Table Row Styles */
tr {
    transition: background-color 0.3s; /* Smooth transition for hover effect */
}

tr:hover {
    background-color: #f0f0f0; /* Hover color */
}

/* Table Cell Styles */
td {
    padding: 8px;
    text-align: left;
    font-size: 14px; /* Adjust font size as needed */
}

/* Add a border to the last cell in each row */
td:last-child {
    border-right: 1px solid #ddd;
}

/* Center the text in the last cell */
td:last-child {
    text-align: center;
}

/* Set a fixed height for table rows (adjust as needed) */
tr {
    height: 40px;
}

/* Add a bit of space between cells */
td, th {
    padding-left: 10px;
    padding-right: 10px;
}

/* Highlight even rows for better readability */
tr:nth-child(even) {
    background-color: #f9f9f9;
}

/* Add a border to the last cell in each row */
td:last-child {
    border-right: 1px solid #ddd;
}

/* Center the text in the last cell */
td:last-child {
    text-align: center;
}

/* Style anchor tags inside table cells */
td a {
    text-decoration: none;
    color: #337ab7; /* Link color */
    transition: color 0.3s; /* Smooth transition for hover effect */
}

td a:hover {
    color: #235a81; /* Hover color */
}


input[type="button"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
}

input[type="button"]:hover {
    background-color: #0056b3;
}

/* Add more styles as needed */

    </style>
</head>
<body>
<a href="individual_teams.php"><input type="button" value="Back"></a>
<?php

echo "<table>
    <tr>
        <th>Team Name</th>
        <th>Team Lead Name</th>
        <th>Team Members</th>
        <th>Attendance Percentage</th>
        <th>Marks Percentage</th>
    </tr>";

// Now fetch team members and team lead
$team_query = "
SELECT t.team_name, t.team_lead_roll, t.team_lead_name, GROUP_CONCAT(tm.member_name) as team_members
FROM teams t
JOIN team_members tm ON t.team_id = tm.team_id
GROUP BY t.team_name;
";

$team_result = $conn->query($team_query);

while($row = $team_result->fetch_assoc()) {
    $team_name = $row["team_name"];
    $attendance_percentage = isset($team_data[$team_name]['attendance_percentage']) ? $team_data[$team_name]['attendance_percentage'] : 'N/A';
    $marks_percentage = isset($team_data[$team_name]['marks_percentage']) ? $team_data[$team_name]['marks_percentage'] : 'N/A';

    echo "<tr>
        <td>".$team_name."</td>
        <td>".$row["team_lead_name"]."</td>
        <td>".$row["team_members"]."</td>
        <td>".$attendance_percentage."%</td>
        <td>".$marks_percentage."</td>
      </tr>";
}

echo "</table>";

$conn->close();
?>

</body>
</html>
<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>