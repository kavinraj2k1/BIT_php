<?php 
session_start();

if (isset($_SESSION['name']) && isset($_SESSION['staff_id']) && isset($_SESSION['designation'])&& isset($_SESSION['domain'])&& isset($_SESSION['user_name'])&& isset($_SESSION['role'])) {

 ?>
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Dashboard | <?php echo $_SESSION['event_org']; ?> <?php echo $_SESSION['event_type']; ?></title>
</head>

<body>

    <div class="container">
        <!-- Sidebar Section -->
        <aside>
            <div class="toggle">
                <div class="logo">
                    <img src="images/logo1.png">
                    <h2><?php echo $_SESSION['event_org']; ?><span class="danger"><?php echo $_SESSION['event_type']; ?> </span></h2>
                </div>
                <div class="close" id="close-btn">
                    <span class="material-icons-sharp">close</span>
                </div>
            </div>

            <div class="sidebar">
                <a href="dashboard.php">
                    <span class="material-icons-sharp">dashboard</span>
                    <h3>Dashboard</h3>
                </a>
                <a href="users.php" >
                    <span class="material-icons-sharp">person_outline</span>
                    <h3>Users</h3>
                </a>
                <a href="problemstatement.php" class="active">
                    <span class="material-icons-sharp">receipt_long</span>
                    <h3>Problem Statement</h3>
                </a>
                <a href="index.php" >
                    <span class="material-icons-sharp">insights</span>
                    <h3>Analytics</h3>
                </a>
                <a href="individual_teams.php">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Teams</h3>
                </a>
                <!-- <a href="#">
                    <span class="material-icons-sharp"> mail_outline</span>
                    <h3>Tickets</h3>
                    <span class="message-count">27</span>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Sale List</h3>
                </a> -->
                <a href="reports.php">
                    <span class="material-icons-sharp">report_gmailerrorred</span>
                    <h3>Reports</h3>
                </a>
                <a href="profile.php">
                    <span class="material-icons-sharp"> settings</span>
                    <h3>Settings</h3>
                </a>
                <a href="new_login.php">
                    <span class="material-icons-sharp">add</span>
                    <h3>New Login</h3>
                </a>
                <a href="create_db.php">
                    <span class="material-icons-sharp">add</span>
                    <h3 id="open-modal-btn1">Create DB</h3>
                </a>
                <a href="../login-session/logout.php">
                    <span class="material-icons-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <!-- End of Sidebar Section -->

        <!-- Main Content -->
        <main>
           
            <!-- End of Analyses -->
            <div class="recent-orders">
            <h2>Problem Statement</h2> 

            <?php
// Check if the success parameter is set
if (isset($_GET['success']) && $_GET['success'] == '1') {
    echo '<div style="color: green;"><h2>Problem Statement Added successfully!</h2></div>';
}
?>

           
            <center><h3 id="open-problem-modal-btn"  class="glow-text">Add Problem Statement</h3></center>
         

            <div id="problem-modal" class="modal">
            <div class="modal-content">
            <span class="close-problem">&times;</span>
            <h2>Add Problem Statement</h2>
            <form action="add_problem_statement.php" method="post">
            <label for="problem-code">Problem Code:</label>
            <input type="text" id="problem-code" name="problem_code" required>
            <label for="problem-statement">Problem Statement:</label>
            <input type="text" id="problem-statement" name="problem_statement" required>
            <label for="domain">Domain:</label>
            <input type="text" id="domain" name="domain" required>
            <button type="submit" id="submit-problem-modal-btn">Submit</button>
            </form>
            </div>
            </div>

                <table>
                
                    <thead> 
                        <tr>   
                            <th>Problem Code</th>
                            <th>Problem Statement</th>
                            <th>Domain</th>
                        </tr>
                    </thead>
                    <tbody id="statement-table"></tbody>
                </table><br>
                <!-- <h3 id="open-event-modal-btn">Add Event</h3> -->
                
            </div>
            <!-- New Users Section -->
            
            <!-- End of New Users Section -->

            <!-- Recent Orders Table -->
            
            <!-- End of Recent Orders -->

        </main>
        <!-- End of Main Content -->
        <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    die();
}

// Initialize variables to store the last notification and its date and time
$lastNotification = "";
$lastDateTime = "";

// Query to fetch the last notification and its date and time from the database
try {
    $stmt_last_notification = $conn->prepare("
        SELECT
            notification,
            date_time
        FROM
            admin_notify
        ORDER BY
            id DESC
        LIMIT 1
    ");
    $stmt_last_notification->execute();

    // Fetch the last notification and its date and time
    $lastNotificationRow = $stmt_last_notification->fetch(PDO::FETCH_ASSOC);
    
    if ($lastNotificationRow) {
        $lastNotification = $lastNotificationRow['notification'];
        $lastDateTime = $lastNotificationRow['date_time'];
    }
} catch (PDOException $e) {
    // Handle database error for fetching the last notification
    echo '<p class="notification">Error fetching the last notification</p>';
}

// Close the database connection
$conn = null;

// Display the last notification and its date and time
// echo '<div class="last-notification">';
// if (!empty($lastNotification)) {
//     echo '<p class="notification">' . $lastNotification . '</p>';
//     echo '<p class="datetime">Date and Time: ' . $lastDateTime . '</p>';
// } else {
//     echo '<p class="notification">No notifications found</p>';
// }
// echo '</div>';
?>
        <!-- Right Section -->
        <div class="right-section">
            <div class="nav">
                <button id="menu-btn">
                    <span class="material-icons-sharp">menu</span>
                </button>
                <div class="dark-mode">
                    <span class="material-icons-sharp active">light_mode</span>
                    <span class="material-icons-sharp">dark_mode</span>
                </div>

                <div class="profile">
                    <div class="info">
                        <p>Hey, <b><?php echo $_SESSION['name']; ?></b></p>
                        <small class="text-muted"><?php echo $_SESSION['role']; ?></small>
                    </div>
                    <div class="profile-photo">
                        <img src="images/profile-1.jpg">
                    </div>
                </div>

            </div>
            <!-- End of Nav -->

            <div class="user-profile">
                <div class="logo">
                    <img src="images/logo1.png">
                    <h2><?php echo $_SESSION['event_org']; ?> <?php echo $_SESSION['event_type']; ?></h2>
                    <p><?php echo $_SESSION['organizer']; ?></p>
                </div>
            </div>

            <div class="reminders">
                <div class="header">
                    <h2>Reminders</h2>
                    <span class="material-icons-sharp">notifications_none</span>
                </div>
                <div class="notification" >
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                        
                    </div>
                    <div class="content" id="blink">
                        <div class="info" >
                            <h3><?php echo ' ' . $lastNotification . '';?></h3>
                            <small class="text_muted"><?php echo ' ' . $lastDateTime . '';?> </small>
                            
                        </div>
                    </div>
                </div>
                <!-- <marquee behavior="scroll" direction="up" scrollamount="5">
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div>
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div>
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div>
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div>
                <div class="notification">
                    <div class="icon">
                        <span class="material-icons-sharp">volume_up</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM</small>
                        </div>
                        <span class="material-icons-sharp">more_vert</span>
                    </div>
                </div>
                <div class="notification deactive">
                    <div class="icon">
                        <span class="material-icons-sharp">edit</span>
                    </div>
                    <div class="content">
                        <div class="info">
                            <h3>Workshop</h3>
                            <small class="text_muted">08:00 AM - 12:00 PM </small>
                        </div>
                        <span class="material-icons-sharp"> more_vert</span>
                    </div>
                </div></marquee> -->

                <div class="notification add-reminder">
                    <div>
                    <span class="material-icons-sharp">add</span>
                        <h3 id="open-modal-btn">Add Reminder</h3>
                        <!-- <button id="open-modal-btn">Open Modal</button> -->
                        <!-- <button id="open-modal-btn" >Add Reminder</button> -->
                    </div>
                </div>
                
                <!-- <button id="open-modal-btn" >Add Reminder</button> -->
                    <div id="modal" class="modal">
                    <div class="modal-content">
                        <span class="close1">&times;</span>
                        <h2>Notification</h2>
                        <form action="notify.php" method="post">
                        <textarea id="message" name="notify" required></textarea>
                        <label for="datetime">Date and Time:</label>
                        <input type="datetime-local" id="datetime" name="datetime" required>
                        <button type="submit" id="submit-modal-btn">Submit</button>
                        </form>
                    </div>
                    </div>
          

            </div>

      


    </div>
    <script src="blink.js"></script>
    <script src="orders.js"></script>
    <script src="fetch_users.js"></script>
    <script src="fetch_statement.js"></script>
    <script src="index.js"></script>
    <script src="model.js"></script>
    <script src="problem_model.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js"></script>
</body>

</html>
<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>